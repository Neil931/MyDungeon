# Partiel SQL SIO1
## Consigne :
- la première partie est un rappel de cours, la seconde partie sont les exercices à faire. les exercices consistent en une série de `select`, en sql commenter du code se fait avec `--`

- les réponses au exercices se feront au niveau des --TODO à partir de la ligne 3541

- les réponses ne sont pas à faire forcément dans l'ordre

- il est strictement interdit de modifier les ligne 1 à 5541

- en cas de modification de ces ligne, vous pourrez les récuperer en copiant le code dans save.sql

- si vous modifiez aussi save.sql, tampis pour vous. 



# partie 1 : Rappel de cours


## Requêtage simple

La requête la plus simple est celle permettant de récupérer l'ensemble des données d'une table. Toute requête d'interrogation de données commence par le mot-clé **`SELECT`** et termine normalement par un point-virgule ("**`;`**").

Voici la requête permettant de récupérer la liste des clients présents dans la base de données (ici, nous utilisons une BD nommée *Comptoir2000*).

```sql
SELECT *
    FROM Client;
```

Voici quelques explications :

- Le terme **`SELECT`** indique donc que nous souhaitons récupérer des données ;
- Le caractère **`*`** indique que l'on veut tous les attributs de la table ;
- Le terme **`FROM`** permet d'indiquer à partir de quelle table nous devons récupérer les données.

## Limitation des résultats

Il est parfois utile de n'avoir que les premières lignes d'une table, pour comprendre son contenu par exemple. Dans ce cas, il est possible d'ajouter en fin de requête le terme **`LIMIT`** suivi du nombre de lignes souhaité.

```sql
SELECT *
    FROM Client
    LIMIT 3;
```

## Ordre des résultatsm

De même, on est souvent appelé à faire un tri des données (ascendant ou descendant). Le terme **`ORDER BY`**, à placer en fin de requête aussi, mais avant le `LIMIT` si nécessaire, permet de réaliser un tel tri. Il faut bien noter que le tri ne se fait qu'à l'affichage et que la table n'est en rien modifiée. De plus, celui-ci peut se faire sur tout type de données.

Il est possible d'indiquer de deux façons le ou les attributs à prendre en compte pour le tri 
- par leur nom
- par leur position dans la table

Les deux requêtes suivantes sont les mêmes et permettent toutes deux d'avoir la liste des employés triés dans l'ordre croissant de leur nom (attribut `Nom` placé en 2ème position).

```sql
SELECT * 
    FROM Employe
    ORDER BY Nom;
```

```sql
SELECT * 
    FROM Employe
    ORDER BY 2;
```

Dans un souci de clarté, il est tout de même préférable d'utiliser la première option.

Ensuite, pour modifier le type de tri, il est possible d'ajouter le terme **`DESC`** pour indiquer qu'on souhaite un tri décroissant. Par défaut, c'est donc un tri croissant qui est fait. 

```sql
SELECT * 
    FROM Employe
    ORDER BY Nom DESC;
```

Il est possible d'avoir plusieurs critères de tri. Pour cela, il faut séparer les différents attributs (nom ou position) par une virgule (*`,`*). La requête suivante permet donc d'avoir les employés triés d'abord par leur fonction, puis par leur nom.

```sql
SELECT * 
    FROM Employe
    ORDER BY Fonction, Nom;
```

Voici la même requête que précédemment, avec les fonctions triées par ordre alphabétique décroissant.

```sql
SELECT * 
    FROM Employe
    ORDER BY Fonction DESC, Nom;
```
# Restriction

Une restriction est une sélection de lignes d'une table, sur la base d'une condition à respecter, définie à la suite du terme **`WHERE`**. Cette condition peut être une combinaison de comparaisons à l'aide de `AND`, de `OR` et de `NOT` (attention donc aux parenthèses dans ce cas).

## Opérateurs classiques

Nous disposons bien sûr de tous les opérateurs classiques de comparaison : `=`, `<>`, `>`, `>=`, `<`, `<=`.

Cette requête permet de lister tous les employés ayant la fonction de représentant.

```sql
SELECT * 
    FROM Employe
    WHERE Fonction = "Représentant(e)";
```

Si l'on souhaite le complément de cette requête, i.e. tous les employés qui ne sont pas représentants, on utilise le symbole `<>` pour indiquer une non-égalité (ce qui revient à faire `NOT(Fonction = "Représentant(e)")`).

```sql
SELECT * 
    FROM Employe
    WHERE Fonction <> "Représentant(e)";
```

Comme indiqué précédemment, il est possible de combiner des comparaisons. La requête suivante permet d'avoir les représentants masculins, avec un numéro d'employé inférieur strictement à 8.

```sql
SELECT * 
    FROM Employe
    WHERE Fonction = "Représentant(e)"
    AND TitreCourtoisie = "M."
    AND NoEmp < 8;
```

Pour les comparaisons de chaînes de caractères, il est important de faire attention à la casse (i.e. minuscule/majuscule). Par définition, un `"a"` est donc différent d'un `"A"`. Pour remédier à ce problème, il existe les fonction **`UPPER()`** et **`LOWER()`** pour transformer une chaîne en respectivement majuscule et minuscule.

```sql
SELECT * 
    FROM Employe
    WHERE UPPER(Ville) = "SEATTLE";
```

## Données manquantes

Une donnée manquante en SQL est repérée par un `NULL`. Il y a plusieurs raisons, bonnes ou mauvaises, pour avoir des données manquantes, et il est parfois utile de tester leur présence. Pour cela, nous allons utiliser le terme **`IS NULL`** comme condition.

Par exemple, pour lister les employés dont la région n'est pas renseignée, nous devons exécuter la requête suivante.

```sql
SELECT * 
    FROM Employe
    WHERE Region IS NULL;
```

Au contraire, si l'on veut uniquement les employés pour lesquels l'information est présente, nous devrons utiliser la négation avec `IS NOT NULL`.

```sql
SELECT * 
    FROM Employe
    WHERE Region IS NOT NULL;
```

## Opérateurs spécifiques

Les deux premiers opérateurs définis ci-après sont particulièrement utiles pour limiter la taille de la requête. Le dernier est lui utile pour comparer une chaîne de caractères à une *pseudo-chaîne*.

### `BETWEEN`

Cet opérateur permet de définir un intervalle fermé dans lequel l'attribut doit avoir sa valeur. La condition suivante est équivalente à `NoEmp >= 3 AND NoEmp <= 8`.

```sql
SELECT * 
    FROM Employe
    WHERE NoEmp BETWEEN 3 AND 8;
```

### `IN`

Cet autre opérateur permet de définir une liste de valeurs entre parenthèses et séparées par des virgules. La condition suivante est équivalente à `TitreCourtoisie = 'Mlle' OR TitreCourtoisie = 'Mme'`.

```sql
SELECT * 
    FROM Employe
    WHERE TitreCourtoisie IN ('Mlle', 'Mme');
```

### `LIKE`

Comme précisé avant, l'opérateur `LIKE` permet de comparer une chaîne de caractère à une *pseudo-chaîne*, dans laquelle nous pouvons ajouter deux caractères spécifiques :

- `%` : une suite de caractères, éventuellement nulle
- `_` : un et un seul caractère

Par exemple, la requête suivante permet de récupérer les employés dont le nom commence par un `"D"`.

```sql
SELECT * 
    FROM Employe
    WHERE Nom LIKE 'D%';
```

La requête suivante permet elle d'avoir tous les employés qui ont un prénom de 5 lettres.

```sql
SELECT * 
    FROM Employe
    WHERE Prenom LIKE '_____';
```

Il faut noter que l'opérateur `LIKE` est insensible à la casse, i.e. il ne tient pas compte des minuscules/majuscules.

# Projection

Une projection est une sélection de colonnes d'une table, sur la base d'une liste d'attributs placés après le `SELECT` et séparés par une virgule.

La requête suivante permet d'avoir uniquement les noms et les prénoms des employés.

```sql
SELECT Nom, Prenom
    FROM Employe;
```

## Doublons

Lors d'une projection, on est souvent en présence de doublons dans les résultats, i.e. deux lignes ou plus identiques.

Par exemple, lorsqu'on liste les fonctions des employés, on a plusieurs fois chaque fonction existante.

```sql
SELECT Fonction
    FROM Employe;
```

Or, dans ce cas, on est souvent intéressé par la liste des valeurs uniques. Pour l'obtenir, il est possible d'ajouter le terme **`DISTINCT`** juste après le `SELECT`, pour supprimer ces doublons.

```sql
SELECT DISTINCT Fonction
    FROM Employe;
```

Ceci fonctionne aussi lorsqu'on a indiqué plusieurs attributs dans le `SELECT`.

## Renommage

Pour améliorer la présentation, il est possible de renommer un attribut (et on le verra plus tard le résultat de calcul), avec le terme **`AS`** placé après l'attribut à renommer et suivi du nouveau nom.

```sql
SELECT DISTINCT Fonction AS "Fonctions existantes"
    FROM Employe;
```

# Calculs arithmétiques


## Calcul simple

Il est possible d'effectuer des calculs arithmétiques dans un `SELECT`, à l'aide des opérateurs classiques : `+`, `-`, `*`, `/`, `()`. 

Voici un premier exemple de calcul dans une requête. On additionne les unités en stock avec les unités commandées, pour chaque produit.

```sql
SELECT *, UnitesStock + UnitesCom
    FROM Produit;
```

Bien évidemment, on peut vouloir faire aussi un projection en même temps, en n'affichant que la référence du produit.

```sql
SELECT RefProd, UnitesStock + UnitesCom
    FROM Produit;
```

### Renommage 

Pour plus de lisibilité, il est d'usage de renommer un calcul, grâce à `AS`. Si l'on désire mettre des accents (en français) et/ou des espaces, il est nécessaire d'ajouter les `"..."` (ou `'...'`). 

```sql
SELECT RefProd AS Reference, 
		UnitesStock + UnitesCom AS "Unités disponibles"
    FROM Produit;
```

Vous remarquerez qu'il est possible de passer à la ligne suivante dans un `SELECT` pour rendre le code plus simple à lire. En effet, en `SQL`, on peut écrire tout sur une même ligne, jusqu'à un mot par ligne. Le moteur du SGBD supprime les espaces inutiles et les sauts de lignes avant l'exécution de la requête. Mais il est important d'avoir un **code lisible** (débugage plus simple, compréhension de celui-ci par un autre aisée, réutilisation facilitée, ...).

Dans cet exemple, nous utilisons la multiplication `*` pour calculer le montant en stock pour chaque produit, égal au prix unitaire multiplié par la quantité de produits en stock.

```sql
SELECT RefProd, 
		PrixUnit * UnitesStock AS "Montant en stock"
    FROM Produit;
```

### Combinaison de clauses

Puisque nous sommes dans une requête `SELECT`, nous pouvons bien évidemment utiliser toutes les restrictions que l'on désire, dans le `WHERE`.

```sql
SELECT RefProd, 
		PrixUnit * UnitesStock AS "Montant en stock indisponible"
    FROM Produit
    WHERE Indisponible = 1;
```

Et bien évidemment, on peut aussi trier le résultat, à l'aide de `ORDER BY`, et se limiter à n lignes, à l'aide de `LIMIT`. Nous avons donc ici les trois produits indisponibles avec le plus haut montant en stock.

```sql
SELECT RefProd, 
		PrixUnit * UnitesStock AS "Montant en stock"
    FROM Produit
    WHERE Indisponible = 1
    ORDER BY 2 DESC
    LIMIT 3;
```

### Calcul complexe

Les calculs peuvent être un peu plus complexes, grâce à l'utilisation des parenthèses. Par exemple, considérons que nous voulons garder au moins 10 unités de chaque produit. Nous calculons dans la requête suivante le montant en stock directement disponible, en tenant compte de la contrainte précédente.

```sql
SELECT RefProd, 
		PrixUnit * (UnitesStock - 10)
    FROM Produit
    WHERE UnitesStock >= 10;
```

Toute expression mathématique combinant les opérateurs classiques est donc acceptable à ce niveau.

### Arrondi

Il est possible d'obtenir l'arrondi d'un réel grâce à la fonction `ROUND()`. Dans l'exemple ci-dessous, nous calculons une augmentation de 5% des prix des produits.

```sql
SELECT RefProd, 
		ROUND(PrixUnit * 1.05) AS "Nouveau Prix"
    FROM Produit;
```

L'arrondi ci-dessus est à l'entier. Si l'on désire un arrondi à 2 décimales (et donc les centimes dans notre cas), il faut ajouter un 2 comme second paramètre de la fonction `ROUND()`.

```sql
SELECT RefProd, 
		ROUND(PrixUnit * 1.05, 2) AS "Nouveau Prix"
    FROM Produit;
```

# Fonctions sur chaînes de caractères

## Concaténation

La première opération que l'on souhaite faire avec des chaînes de caractères est la concaténation : le regroupement des deux chaînes en une seule. Par exemple, la concaténation de `"bon"` et de `"jour"` donne la chaîne `"bonjour"`. L'opérateur dédié en `SQL` est `||`. L'exemple ci-dessous nous permet d'avoir le nom et le prénom dans une seule chaîne.

```sql
SELECT NoEmp, Nom || Prenom
    FROM Employe;
```

Avec la requête ci-dessus, les deux chaînes sont collées, i.e. il n'y a pas d'espace entre les deux. Pour cela, il est tout à fait possible de concaténer en une expression plusieurs chaînes pour introduire un espace, comme ci-après.

```sql
SELECT NoEmp, Nom || " " || Prenom
    FROM Employe;
```

## Extraction d'une sous-chaîne

Une commande intéressante sur les chaînes est la commande `SUBSTR(chaine, debut, longueur)` qui permet d'extraire une sous-chaîne d'une chaîne, en partant du caractère précisé dans `debut` et sur une longueur précisé par `longueur`. Dans l'exemple ci-dessous, nous extrayons l'initiale du prénom.

```sql
SELECT NoEmp, Nom || " " || SUBSTR(Prenom, 1, 1)
    FROM Employe;
```

Et on ajoute un `"."` pour indiquer que c'est une initiale. Il n'y a pas de limite sur le nombre de chaînes que l'on peut concaténer en une seule expression.

```sql
SELECT NoEmp, Nom || " " || SUBSTR(Prenom, 1, 1) || "."
    FROM Employe;
```

## Majuscule/Minuscule

Pour pouvoir transformer une chaîne en majuscule (et respectivement en minuscule), nous avons à disposition la commande `UPPER(chaine)` (et resp. `LOWER(chaine)`). Cette commande, comme toutes les autres, peut aussi être utilisé dans un `WHERE`.

```sql
SELECT NoEmp, UPPER(Nom) || " " || SUBSTR(Prenom, 1, 1) || "."
    FROM Employe;
```

La commande `LENGTH(chaine)` permet de renvoyer la longueur de la chaîne (i.e. le nombre de caractères, y compris les espaces).

```sql
SELECT NoEmp, Nom, LENGTH(Nom)
    FROM Employe;
```

## Modification d'une sous-chaîne

La commande `REPLACE(chaîne, sc1, sc2)` permet de remplacer la sous-chaîne `sc1` par la sous-chaîne `sc2` dans la chaîne de caractères passée en premier paramètre. Ci-dessous, nous remplaçons donc le terme `"Chef"` par le terme `"Responsable"` dans les titres de fonction des employés.

```sql
SELECT Nom, Prenom, Fonction,
        REPLACE(Fonction, "Chef", "Responsable")
    FROM Employe;
```

## Recherche d'une sous-chaîne

Pour rechercher la première apparition d'une sous-chaîne dans une chaîne, nous disposons de la commande `INSTR(chaîne, souschaine)`. Celle-ci recherche donc à quelle position dans la chaîne se trouve la première occurence de la sous-chaîne. Si la sous-chaîne n'est pas présente, la fonction renvoie `0`.

Ci-dessous, nous cherchons la présence du terme `"Ave."` dans l'adresse des employés. 

```sql
SELECT Nom, Adresse,
        INSTR(Adresse, "Ave.")
    FROM Employe;
```



# Partie 2: Exercices

1. Lister le contenu de la table `Track`
2. N'afficher que les 5 premiers produits
3. Trier tous les produits par leur compositeur (attribut `Composer`)
4. Afficher les 10 premiers produits trié par leur titre (attribut `Name`)
5. Lister les titres de l'artiste 'AC/DC' dont le temps de chanson est superieur à 300000 milliseconds
6. Lister les titres des artistes : 'Apocalyptica', 'Chuck Berry' et 'Ozzy Osbourne'
7. Lister les titres dont l'artiste n'est pas renseigné
8. Lister les titres dont le nom contient `"rock"` (nom présent dans la colonne `Name`) la recherche ne dois pas être sensible à la casse

9. Lister uniquement les noms d'artistes (table `Composer`)

10. Lister les différents prix des titres
11. Idem en ajoutant les nom, le tout trié par ordre alphabétique du nom et par prix
 


12. Afficher pour l'artiste `AC/DC`, pour chaque produit acheté Afficher:
	- le prix unitaire des titres,
	- le prix moyen si 500 000 titres sont vendu, 
	- le prix si 20 000 titre sont vendu avec une réduction de 20%, 


13. Concaténer les champs `Name`, `Composer` et `UnitPrice` dans un nouveau champ nommé `info Track`, pour avoir :
```
Compositeur, Titre, prix
```
14. Extraire les deux premiers caractères des titres (`Name`)
15. Mettre en minuscule le nom des Artistes (`Composer`)
16. Remplacer le terme `"love"` par `"hate"` dans les titres
17. Indiquer la présence du terme `"rock dans les titres