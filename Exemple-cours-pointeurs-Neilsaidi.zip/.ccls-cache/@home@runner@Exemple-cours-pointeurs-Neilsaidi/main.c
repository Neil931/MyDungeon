#include <stdio.h>

void swap(int *a, int *b);

int main(void) {
    //POINTEURS
    int a = 10;
    int c = 34;
    int *b = &a;
    *b = 15;
    printf("a = %d, c = %d\n",a ,c);
    printf("%p\n", b);
    //printf("%d\n", b);
    printf("%d\n", a);
    swap(&a, &c);
    printf("a = %d, c = %d\n",a ,c);
    //BIDIMENTIONNAL ARRAY
    //déclaration tableau à une dimention
    
    int e[3] = {1, 5, 3};

    //equivalent à 
    int *x = malloc(sizeof(int) * 3);
    x[0] = 1;
    x[1] = 5;
    x[2] = 3;
    //
  
    int f[3] = {4, 7, 9};
    int g[3] = {21, 5, 0};

    //déclaration tableau à 2 dimentions
  
    printf("%p\n", e);
    printf("%p\n", e + 1);
    printf("%d\n", *e);
    printf("%d\n", *(e + 1));
    printf("%d\n", e[1]);

    int h[2][3] = {
        {1, 5, 3},
        {4, 7, 9},
    };
    
    printf("%d\n", h[0][0]);

    //Affichage
    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 3; j++){
            printf("%d ", h[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    
    h[0][2] = 15;

    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 3; j++){
            printf("%d ", h[i][j]);
        }
        printf("\n");
    }
    
    return 0;
}

int add(int a, int b){
    int c = a + b;
    return c;
}

void swap(int *a, int *b){
    int c = *a;
    *a = *b;
    *b = c;
}
