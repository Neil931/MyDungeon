#include <stdio.h>
#include "char_array.h"
#include "game.h"

int main() { 
 
  char a[3][3] = {    
  {'o','o','o'},
  {'o','o','o'},
  {'o','o','o'}
  };    
  init_grid(a, '-');   
  
  update_grid(a, 'x', 0, 2);
  update_grid(a, 'x', 1, 1);  
  update_grid(a, 'x', 2, 0);    
  display_grid(a);  

  int b = test_win(a, 'x');
  printf("%d\n", b);   

/*
// Palier 3 :  
  char a[3][3] = {      
  {'.','.','.'},
  {'.','.','.'},
  {'.','.','.'}  
  };  
  int x; 
  int y;   
  char c; 
  int compteur = 0; 

  while (compteur <= 9){
    
    printf( "Joueur 1, veuillez saisir x : " );
    scanf( "%d", &x );
    printf( "Joueur 1, veuillez saisir y : " );
    scanf( "%d", &y );
    
    update_grid(a, 'x', x, y);
    display_grid(a);    
    if (test_win (a, 'x') == 1){
      printf("Le joueur 1 a gagné \n");      
      break;    
    }    

    printf( "Joueur 2, veuillez saisir x : " );
    scanf( "%d", &x );
    printf( "Joueur 2, veuillez saisir y : " );
    scanf( "%d", &y );

    update_grid(a, 'o', x, y);
    display_grid(a);  
    if (test_win (a, 'o') == 1){
      printf("Le joueur 2 a gagné \n");
      break;    
    }
     compteur = compteur + 2;       
  }  
  if (compteur >= 9){
    printf("Match nul");      
  }  
*/
  return 0;
} 