#include <stdio.h>
#include <stdlib.h>
#include "game.h"

// EXERCICE 4 : test_win 
int test_win(char (*grid)[3], char c){    
  int nbc = 0; 

  // Test lignes :
  for (int i = 0; i < 3; i++){        
    for (int j = 0; j < 3; j++){  
      
      if (grid[i][j] == c){
        nbc++;           
      }      
    }       
    if (nbc == 3) return 1; 
    nbc = 0; 
  }  

  // Test colonnes :
  for (int j = 0; j < 3; j++){     
    for (int i = 0; i < 3; i++){ 
      
      if (grid[i][j] == c){
        nbc++;         
      }           
    }  
    if (nbc == 3) return 1; 
    nbc = 0; 
  } 

  // Test diagonales
  int nbc_diag = 0; 
   
  for (int i = 0; i < 3; i++){     
    for (int j = 0; j < 3; j++){ 
      
      if (grid[i][j] == c && i == j){
        nbc++;         
      }  
       if (grid[i][j] == c && 2-i == j){
        nbc_diag++;         
      }     
    }   
  }   
  if (nbc == 3 || nbc_diag == 3) return 1;  
  
  return 0;
}


