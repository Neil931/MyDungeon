#include <stdio.h>

int even(int);
int min(int, int, int);
int is_pos(int, int);
void day_of_week(int);
void simple_series(int);
void even_series(int);
void facteur(int);
int simple_sum(int);
int count_nbr(int);
void array_odd(int[], int);
int array_sum(int[], int);
void array_mv(int array_src[], int array_dst[], int tailleTableau);
void array_sort(int array[], int size);

int main(void) {
  
  int a = even(2); 
  printf("even : %d \n", a); //doit afficher 1

  int b = min(2, 5, 4);
  printf("min : %d \n", b); //doit afficher 2
  
  int c = is_pos(2, -1);
  printf("is_pos : %d \n", c); //doit afficher 0
    
  day_of_week(2); 
  simple_series(3); //doit afficher 1, 2, 3  
  even_series(10); //doit afficher 2, 4, 6, 8

  // factor(20); //doit afficher 1, 2, 4, 5, 10, 20

  int d = simple_sum(5); //renvois le calcul 1+2+3+4+5
  printf("simple_sum : %d \n", d);

  int e = count_nbr(23121); 
  printf("count_nbr : %d \n", e); //affiche 5

  /*  
  int f[5] = {1, 2, 4, 8, 7};
  array_odd(f, 5); //affiche 2, 4, 8
  ::
  int g[5] = {1, 2, 4, 8, 7};
  int h = array_sum(g, 5);
  printf("array_sum : %d \n", h); //affiche 22
  */  
  /*  
  int i[5] = {1, 2, 4, 8, 7};
  int j[5] = {7, 5, 4, 8, 1};
  array_mv(i, j, 5);
  print_array(i, 5); 
  print_array(j, 5);  
  ::
  int k[5] = {1, 2, 4, 8, 7};
  array_sort(k, 5);
  print_array(k, 5); // affiche {81, 22, 15, 13}
  */

  return 0;
}

// EXERCICE 00 :
int even(int a){
  if (a % 2 == 0){
    return 1;
  }
  else{
    return 0;
  }
}

// EXERCICE 01 :
int min(int x, int y, int z){
  if (x < y && x < z){
    return x;
  }
  else if (y < x && y < z){
    return y;
  }
  else if (z < x && z < y){
    return z;
  }
  return 0;
}

// EXERCICE 02 :
int is_pos(int v, int w){
  if (v * w > 0){
    return 1;
  }
  else{
    return 0;
  }
}

// EXERCICE 03 :
void day_of_week(int u){
  if (u == 0){
    printf ("Dimanche\n");
  }
  else if (u == 1){
    printf ("Lundi\n");
  }
  else if (u == 2){
    printf ("Mardi\n");
  }
  else if (u == 3){
    printf ("Mercredi\n");
  }
  else if (u == 4){
    printf ("Jeudi\n");
  }
  else if (u == 5){
    printf ("Vendredi\n");
  }
  else if (u == 6){
    printf ("Samedi\n");
  }
}

// EXERCICE 04 :
void simple_series(int t){
  int a = 1;
  while (a < t + 1){
    printf ("%d ", a);
    a = a + 1;
  } 
}

// EXERCICE 05 :
void even_series(int s){
  int a = 1;
  while (a < s + 1){
    if (a % 2 == 0){
      printf ("%d ", a);
    }
    a = a + 1;
  }    
}

// EXERCICE 06 :
void facteur(int);


// EXERCICE 07 :
int simple_sum (int d){
  int x = 1;
  int y = 0;
  while (x < d + 1){
    y = y + x;
    x = x + 1;
  }
  return y;
}

// EXERCICE 08 :
int count_nbr(int e){
  int nbr = 0;  
  while (e > 1){
    nbr = nbr + 1;
    e = e / 10;
  }
  return nbr;
}

// EXERCICE 09 :
void array_odd(int tab[], int f){
  if (tab[0] % 2 == 0){
    printf ("array_odd : %d", f);
  }  
}

// EXERCICE 10 :
int array_sum(int[], int);

// EXERCICE 11 :
void array_mv(int array_src[], int array_dst[], int tailleTableau);

// EXERCICE 12 :
void array_sort(int array[], int size);







