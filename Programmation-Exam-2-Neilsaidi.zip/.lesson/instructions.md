# Exam : Fonctions et tableaux
## Consigne : 


***TOUT VOS PRINTF DOIVENT FINIR PAR \n ***

le code des Exercice doivent être écrit à la place des //TODO

## rappel de syntax
```c
int a = 10;         //Entier
char c = 'a';       //Charactere
char* d = "toto";   //Chaine de Charactere
double e = 1.34;    //Réel

printf("%d \n", a); //affiche un entier
printf("%c \n", c); //affiche un caractère
printf("%s \n", d); //affiche une chaine
printf("%f \n", e); //affiche un réel

//Structure conditionnelle
if (/*Expression Boolean*/){
    //Calcules
}
else if (/*Expression Boolean*/){
    //Calcules
}
else {
    //Calcules
}

//Structure repetitive
int i = 0;
while(/*Expression boolean vrai*/){
    //Calcules
    i++;
}

for(int i = 0; i < /*nombre de boucle à faire */; i++){
    //Calcules
}

//Déclaration de fonction
type_valeur_de_retour identifiant_fonction(type_parametre_1 identifiant_parametre_1, ...){
    //Calcules
}

//exemple : 
int add(int a, int b){
    int c = a + b;
    return c;
}

//prototype : 
int add(int, int);

//utilisation : 
int a = add(5, 10);
printf("%d\n", a);

//tableaux 
int a[20]; //créer un tableau de 20 cases
int b[5] = {1, 4, 1, 5, 1}; //créer un tableau de 5 cases et les initialise à 1, 4, 1, 5, 1

b[0] = 10; // modifie la case 0 à 10

printf("%d \n", b[3]); //affiche la case à l'index 3

//parcours de tableau: 
for(int i = 0; i < TAILLE_DU_TABLEAU; i++){
    b[i] = 0;
}
```
### Pour le partiel, la fonction : print_array qui affiche les valeurs d'un tableau est fourni :
```c
//Prototype :
void print_array(int[], int);
//définitionm :
void print_array(int a[], int size){
    printf("{ %d", a[0]);
    for(int i = 1; i < size; i++){
        printf(",%d ", a[0]);
    }
    printf("}\n");
}
```

## Exercice 0 :
Écrivez une fonction `even` qui vérifie si un nombre est pair ou impair en utilisant if-else.
la fonction renvois 1 si le nombre est pair, 0 sinon (la fonction printf est interdite dans la fonction `even`)

prototype : 

```c
int even(int);
```

exemple d'utilisation : 
```c
int a = even(2);
printf("%d \n", a); //doit afficher 1
```

## Exercice 1 : 
Écrivez une fonction `min` qui renvois le minimum entre trois nombres en utilisant une if-else ou if imbriquée.

prototype : 

```c
int min(int, int, int);
```

exemple d'utilisation : 
```c
int a = min(2, 5, 4);
printf("%d \n", a); //doit afficher 2
```

## Exercice 2 : 
Écrivez une fonction `is_pos` qui renvois 1 si le résultat d'une multiplication est positif, 0 sinon sans utiliser l'opérateur fois *.

prototype : 

```c
int is_pos(int, int);
```

exemple d'utilisation : 
```c
int a = is_pos(2, -1);
printf("%d \n", a); //doit afficher 0
```

## Exercice 3 : 
Ecrivez une fonction `day_of_week` qui affiche le nom du jour de la semaine correspondant (0-6) 0 etant dimanche. tous les nombres en dehors de 0-6 doivent afficher un message d'erreur

prototype : 

```c
void day_of_week(int);
```

exemple d'utilisation : 
```c
day_of_week(2); //doit afficher mardi
day_of_week(12); //doit afficher "erreur, nombre non compris entre 0 et 6"
```

## Exercice 4 : 
Ecrivez une fonction `simple_series` qui affiche tous les nombre de 1 à n

prototype : 

```c
void simple_series(int);
```

exemple d'utilisation : 
```c
simple_series(3); //doit afficher 1, 2, 3
```

## Exercice 5 : 
Ecrivez une fonction `even_series` qui affiche tous les nombre pair de 2 à n non compris

prototype : 

```c
void even_series(int);
```

exemple d'utilisation : 
```c
even_series(10); //doit afficher 2, 4, 6, 8
```

## Exercice 6 : 
Ecrivez une fonction `factor` qui affiche tous les facteur du nombre n

prototype : 

```c
void facteur(int);
```

exemple d'utilisation : 
```c
factor(20); //doit afficher 1, 2, 4, 5, 10, 20
```

## Exercice 7 : 
Ecrivez une fonction `simple_sum` renvois la somme des nombre de 1 à n 

prototype : 

```c
int simple_sum(int);
```

exemple d'utilisation : 
```c
int a = simple_sum(5); //renvois le calcul 1 + 2 + 3 + 4 + 5
printf("%d\n", a);
```

## Exercice 8 : 
Ecrivez une fonction `count_nbr` qui compte le nombre de chiffre dans un nombre n

prototype : 

```c
int count_nbr(int);
```

exemple d'utilisation : 
```c
int a = count_nbr(23121); 
printf("%d\n", a); //affiche 5
```

## Exercice 9 :
Créez une fonction `array_odd` qui va afficher tous les éléments pair d'un tableau passé en paramètres

```c
void array_odd(int[], int);
```

exemple d'utilisation : 
```c
int a[5] = {1, 2, 4, 8, 7};
array_odd(a, 5); //affiche 2, 4, 8
```

## Exercice 10 :
Créez une fonction `array_sum` qui renvois la somme des nombre d'un tableau d'entier

```c
int array_sum(int[], int);
```

exemple d'utilisation : 
```c
int a[5] = {1, 2, 4, 8, 7};
int b = array_sum(a, 5); 
printf("%d \n", b); //affiche 22
```

## Exercice 11
Créez une procédure `array_mv` qui prend en paramètre deux tableaux. Le contenu du premier tableau (src) devra être copié dans le second tableau (dst) et toutes les valeurs du premier tableau devront être mise à 0.

les tableaux doivent être de même taille

```c
void array_mv(int array_src[], int array_dst[], int tailleTableau);
```
exemple d'utilisation : 
```c
int a[5] = {1, 2, 4, 8, 7};
int b[5] = {7, 5, 4, 8, 1};
array_mv(a, b, 5);
print_array(a, 5); // affiche {0, 0, 0, 0, 0}
print_array(b, 5); // affiche {1, 2, 4, 8, 7}
```

## Exercices 12
Créez une fonctionor `array_sort` qui classe les valeurs d'un tableau dans l'ordre décroissant. Ainsi, un tableau qui vaut {15, 81, 22, 13} doit à la fin de la fonction valoir {81, 22, 15, 13}

```c
void array_sort(int array[], int size);
```
exemple d'utilisation : 
```c
int a[5] = {1, 2, 4, 8, 7};
array_sort(a, 5);
print_array(a, 5); // affiche {81, 22, 15, 13}

```