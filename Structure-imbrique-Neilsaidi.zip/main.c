#include <stdio.h>

int main(void) {

//EXERCICE 1 : Villes et villages
  int nbr_ville;
  int a = 0;
  int hab;
  int ville = 0;

  printf ("nombre de ville à vérifier:");
  scanf ("%d", &nbr_ville);

  if (nbr_ville > 0){
    while (a != nbr_ville){
      printf ("entrez le nombre d'habitants:");
      scanf ("%d", &hab);
      if (hab >= 10000){
        ville = ville + 1;
      }
        a = a + 1;
      }
        printf ("%d\n", ville);
    }
//EXERCICE 2 :
  return 0;
}