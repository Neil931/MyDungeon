# Structure imbriqué

## Cours

 Vous avez déjà appris que, lorsqu'on place une boucle de répétition à l'intérieur d'une autre boucle de répétition, la boucle imbriquée (celle qui se situe à l'intérieur de l'autre) doit être comprise entre accolades, et, pour des raisons de lisibilité, doit avoir tout son code indenté (décalé vers la droite). De la même manière, il faut indenter correctement le code lorsqu'un bloc conditionnel (« si » ou « si/sinon ») est placé à l'intérieur d'une boucle de répétition ou d'un autre bloc conditionnel, ou bien lorsqu'une boucle de répétition est placé à l'intérieur du corps d'un test. Et surtout, il ne faut pas oublier les accolades.

Le programme suivant illustre cela dans le cas d'une boucle de répétition placé à l'intérieur d'un if. Ce programme lit un entier nommé cible. Si cible est un nombre positif, le programme affiche tous les entiers compris entre 1 et cible à l'aide d'une boucle de répétition. Sinon, le programme affiche le texte « Rien à faire ». 
```c
int cible;
scanf("%d", &cible);
if (cible >= 0)
{
   for (int numero = 1; numero <= cible; numero = numero + 1)
   {
      printf("%d\n", numero);
   }
}
else
{
   printf("Rien à faire");
} 
```

## Exercices
### Exercice 1 : Villes et villages



Au cours de votre périple, vous traversez de nombreux lieux habités. Pour chacun d'entre eux, vous notez soigneusement sa population. Après quelques semaines de voyage, vous avez vraiment l'impression qu'il y beaucoup de villages et très peu de villes.

#### Ce que doit faire votre programme :

On vous donne le nombre d'habitants d'un certain nombre de lieux que vous visitez. Une ville étant un lieu dont la population est strictement supérieure à 10 000 habitants, déterminez combien de lieux sont des villes.

Votre programme doit lire un entier : le nombre de lieux. Il doit ensuite lire, pour chaque lieu, un entier donnant le nombre de gens qui y habitent. Votre programme doit alors afficher le nombre de villes.

#### Exemple 
```
 entrée :

6
1000
5000
15000
4780
0
23590

sortie :

2
```

### Exercice 2 