#ifndef DUNGEON_H
#define DUNGEON_H
#include "person.h"

extern void fight(Person *p);
extern void strike(Person *p1, Person *p2);
extern void dungeon(Person *p);

#endif