
#include <stdio.h>
#include <stdlib.h>
#include "person.h"
#include "dungeon.h"

int main(void){   
  Person *p = build_person(100,100,7,5);    
  dungeon(p);
  free(p);
  
  return 0;  
}