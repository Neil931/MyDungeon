#include "person.h"
#include <stdio.h>
#include <stdlib.h>

Person *build_person(int hp, int hp_max, int atk, int def){
  Person *p = malloc(sizeof(Person));  
 
  p->hp = hp; 
  p->hp_max = hp_max;
  p->atk = atk; 
  p->def = def; 
  return p;
}

void display_stats(Person *p){
  printf("Stats :\n hp = %d\n hp_max = %d\n atk = %d\n def = %d \n", p->hp, p->hp_max, p->atk, p->def);
}

void rest_up(Person *p){
  p->hp_max = p->hp_max + p->hp_max/3; 
  display_stats(p);
}

int is_dead(Person *p){
  if(p->hp <= 0){
     return 1;    
  }
  else{
     return 0;     
  }  
}