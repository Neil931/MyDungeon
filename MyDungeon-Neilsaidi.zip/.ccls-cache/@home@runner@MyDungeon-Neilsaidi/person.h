#ifndef PERSON_H
#define PERSON_H

typedef struct {
    int hp;     //les points de vie
    int hp_max; //les points de vie maximum
    int atk;    // les points d'attaque
    int def;    // les points de defense 
} Person;

extern Person *build_person(int hp, int hp_max, int atk, int def);
extern void display_stats(Person *p); 
extern void rest_up(Person *p);
extern int is_dead(Person *p);

#endif