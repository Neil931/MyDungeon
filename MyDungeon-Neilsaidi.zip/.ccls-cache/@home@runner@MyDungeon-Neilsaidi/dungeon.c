#include "dungeon.h"
#include "person.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>

void fight(Person *p){
  int atk = (rand() % (10 + 1 - 1)) + 1;  
  int def = (rand() % (10 + 1 - 1)) + 1;
  //si perso a gagne renovyer 1 sinon 0
  //je crée le montre   
  Person *m = build_person(100,100, atk, def); 
 
  while(1){       
    //le perso attaque le montre
    strike(p,m); 
    //si le montre est mort on arrete 
    if (is_dead(m)==1){
      printf("Vous avez gagné le combat\n");
      break;
    }
    //le montre attaque 
    strike(m,p); 
    //si le perso est mort on arrete 
    if (is_dead(p)==1 ){
      printf("Vous avez perdu le combat\n");
      break;
    }
  }  
}

void strike(Person *p1, Person *p2){
 if (p1->atk - p2->def > 0){
    p2->hp = p2->hp - (p1->atk - p2->def);
  } 
}

void dungeon(Person *p){
  int choix;
  
  while(1){   
    printf("Veuillez saisir votre choix :\n");  
    printf("1 : Lancer un combat - 2 : Se reposer - 3 : Afficher les stats - 0 : Arreter le jeu \n");      
    scanf("%d", &choix);
    if(choix == 0){
    break;
    }
    else if(choix == 1){
      printf("Lancement du combat :\n");     
      fight(p);         
    }
    else if(choix == 2){    
      printf("Statistique après repos :\n");    
      rest_up(p);   
    }
    else if(choix == 3){ 
      printf("Vos Statistique :\n");  
      display_stats(p);
    }
    else{
      printf("Choix indisponible, Veuillez saisir 1, 2 ou 3\n");
    }      
  }   
}