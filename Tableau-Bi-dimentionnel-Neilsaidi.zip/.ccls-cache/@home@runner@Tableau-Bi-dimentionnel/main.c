#include <stdio.h>

void print_array(int (*tab)[3], int x, int y);

int main(void) {
    int tab[2][3] = {
        {1, 5, 1},
        {7, 3, 2}
    }
    print_array(tab, 2, 3);    
    return 0;
}

void print_array(int (*tab)[3], int x, int y){
      for (int i = 0; i < x; i++){
        for (int j = 0; j < y; j++){
            printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);
        }
    }
}