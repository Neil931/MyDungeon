#include <stdio.h>

//void print_array(int (*ext)[3], int x, int y);
void even_biarray(int (*tab)[5], int x, int y);
void odd_biarray(int (*tab)[5], int x, int y);
void diag_biarray(int (*tab)[5], int x, int y);
void eqdiag_biarray(int (*tab)[5], int x, int y);

void init_biarray(int (*tab)[5], int x, int y);
void initn_biarray(int (*tab)[5], int x, int y, int n);

int sum_biarray(int (*tab)[5], int x, int y);
void sum_row_biarray(int (*tab)[5], int x, int y);
void sum_col_biarray(int (*tab)[5], int x, int y);
int sum_diag_biarray(int (*tab)[5], int x, int y);

void switch_diag_biarray(int (*tab)[5], int x, int y);
void mul_n_biarray(int (*tab)[5], int x, int y, int n);

void mul_biarray(int (*tab1)[5], int (*tab2)[5], int (*resultat)[5], int x, int y);

int main(void) {
  /*
    int ext[2][3] = {{1, 5, 1}, {7, 3, 2}};
    print_array(ext, 2, 3);    
  */

    int tab[5][5]={{6,2,3,5,6},{4,6,2,6,1},{1,3,6,7,9},          
    {1,6,3,6,8},{6,0,1,4,6}};     
  /*
    printf("even_biarray : \n"); 
    even_biarray(tab, 5, 5);

    printf("odd_biarray : \n");
    odd_biarray(tab, 5, 5); 

    printf("diag_biarray : \n");
    diag_biarray(tab, 5, 5);

    printf("eqdiag_biarray : \n");
    eqdiag_biarray(tab, 5, 5);

    printf("init_biarray : \n");
    init_biarray(tab, 5, 5);   

    printf("initn_biarray : \n");
    initn_biarray(tab, 5, 5, 5);
  */    
    printf("sum_biarray : \n");     
    printf("somme = %d \n", sum_biarray(tab, 5, 5));

    printf("sum_row_biarray : \n"); 
    sum_row_biarray(tab, 5, 5);

    printf("sum_col_biarray : \n"); 
    sum_col_biarray(tab, 5, 5);

    printf("sum_diag_biarray : \n"); 
    printf("somme diagonal : %d \n", sum_diag_biarray(tab, 5,        5));
                
    printf("switch_diag_biarray : \n"); 
    switch_diag_biarray(tab, 5, 5); 

    printf("mul_n_biarray : \n"); 
    mul_n_biarray(tab, 5, 5, 2); 

    //EX6
    int tab1[5] = {6, 2, 3, 5, 6}; 
    int tab2[5] = {4, 6, 2, 6, 1};
    int resultat[5];

    printf("switch_diag_biarray : \n"); 
    //switch_diag_biarray(tab1, tab2, resultat);    

    return 0;   
}
/*
(tab,5, 5);
id print_array(int (*ext)[3], int x, int y){
      for (int i = 0; i < x; i++){
        for (int j = 0; j < y; j++){
            printf("ext[%d][%d] = %d \n", i, j, ext[i][j]);
        }
    }    
}
*/

// EXERCICE 1.1 :
void even_biarray(int (*tab)[5], int x, int y){

  for (int i = 0; i < x; i++){  

    for (int j = 0; j < y; j++){

      if (i % 2 == 0){
        printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);  
      }            
    }
  }    
}

// EXERCICE 1.2 :
void odd_biarray(int (*tab)[5], int x, int y){

  for (int i = 0; i < x; i++){ 
    for (int j = 0; j < y; j++){  

      if (i % 2 != 0){
        printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);  
      }            
    }
  }    
}

// EXERCICE 1.3 :
void diag_biarray(int (*tab)[5], int x, int y){

  for (int i = 0; i < x; i++){   
    for (int j = 0; j < y; j++){ 

      if (i == j){
        printf("tab[%d][%d] = %d \n", i, j, tab[i][j]); 
      }            
    }
  }
}

// EXERCICE 1.4 :
void eqdiag_biarray(int (*tab)[5], int x, int y){  

  for (int i = 0; i < x; i++){    
    for (int j = 0; j < y; j++){  

      if (i == j || j == y - i- 1){

        if (tab[0][0] != tab[i][j]) {          
          printf("NON \n");          
          return;  
        }
      }            
    }
  }
  printf("OUI \n");  
}

// EXERCICE 2.1 :
void init_biarray(int (*tab)[5], int x, int y){
  
  for (int i = 0; i < x; i++){
    for (int j = 0; j < y; j++){ 

      tab[i][j] = 0;        
      printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);          
    }
  }
}

// EXERCICE 2.2 :
void initn_biarray(int (*tab)[5], int x, int y, int n){

  for (int i = 0; i < x; i++){
    for (int j = 0; j < y; j++){ 

      tab[i][j] = n;        
      printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);          
    }
  }
}

// EXERCICE 3.1 :
int sum_biarray(int (*tab)[5], int x, int y){
  int sum = 0;
  
  for (int i = 0; i < x; i++){
    for (int j = 0; j < y; j++){ 

      sum = sum + tab[i][j];         
    }
  }    
  return sum;  
}

// EXERCICE 3.2 :
void sum_row_biarray(int (*tab)[5], int x, int y){
  int sum = 0;

  for (int i = 0; i < x;i++){
    for (int j = 0; j < y;j++){

      sum = sum + tab[i][j];      
    } 
    printf("Somme ligne %d = %d \n", i, sum);
    sum = 0;
  }    
}

// EXERCICE 3.3 :
void sum_col_biarray(int (*tab)[5], int x, int y){
  int sum = 0;

  for (int i = 0; i < x;i++){
    for (int j = 0; j < y;j++){     

      sum = sum + tab[j][i];      
      }       
    printf("Somme colonne %d = %d \n", i, sum);
    sum = 0;       
  }  
}

// EXERCICE 3.4 :
int sum_diag_biarray(int (*tab)[5], int x, int y){
  int sum = 0;

  for (int i = 0; i < x;i++){
    for (int j = 0; j < y;j++){

      if (i == j){   
        sum = sum + tab[i][j];        
      }      
    }     
  } 
  return sum; 
}

// EXERCICE 4 : 
void switch_diag_biarray(int (*tab)[5], int x, int y){  
  int tab2[5][5];

  for (int i = 0; i < x;i++){
    for (int j = 0; j < y;j++){     
      
      tab2[j][i] = tab[i][j];               
    }     
  } 
  tab = tab2;
  for (int i = 0; i < x; i++){   
    for (int j = 0; j < y; j++){  

      printf("%d ", tab[i][j]);    
    }
    printf("\n");
  }    
} 

// EXERCICE 5 : 
void mul_n_biarray(int (*tab)[5], int x, int y, int n){

  for (int i = 0; i < x; i++){
    for (int j = 0; j < y; j++){ 

      tab[i][j] =  tab[i][j] * n;                    
    }
  }
}

// EXERCICE 6 : 
void mul_biarray(int (*tab1)[5], int (*tab2)[5], int (*resultat)[5], int x, int y){ 

  for (int i = 0; i < 5; i++){    
    //resultat[i] = tab1[i] * tab2[i]; 
  }    
}



 