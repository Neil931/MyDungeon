#include <stdio.h>

int main(void) {
    
/* Variables */
/* exercice 0 */
    int variableEx0 = 8;    

/* exercice 1 */
    int variableEx1_1 = 4;
    int variableEx1_2 = 2;
    int variableEx1_3 = 1;

/* exercice 2 */
    int variableEx2 = 0;
   
/* exercice 3 */
    int variableEx3 = 0;

/* exercice 4 */
    char variableEx4 = 'a';

/* exercice 5 */
    int variableEx5 = 1;
 
/* exercice 6 */
    char variableEx6[64] = "Mai";

/* exercice 7 */
    int variableEx7_fab = 0;
    int variableEx7_ven = 0; 

/* exercice 8 */
    int variableEx8 = 0; 

/* exercice 9 */
    char variableEx9 = 'a'; 


/**
                DEBUT DU DEVOIR
**/

/* exercice 0 */
if (variableEx0 % 2 != 0){
    printf("impair\n");
}
else {
    printf("pair\n");
}

/* exercice 1 */
if (variableEx1_1 > variableEx1_2 && variableEx1_1 > variableEx1_3){
    printf("variableEx1_1 : %d \n", variableEx1_1);
}
else if (variableEx1_2 > variableEx1_1 && variableEx1_2 > variableEx1_3){
    printf("variableEx1_2 : %d \n", variableEx1_2);
}
else {
    printf("variableEx1_3 : %d \n", variableEx1_3);
}

/* exercice 2 */
if (variableEx2 % 3 == 0 && variableEx2 % 13 == 0){
    printf("divisible \n");
}
else {
    printf("non divisible\n");
}

/* exercice 3 */
if (variableEx3 < 10){
    printf("recalé \n");
}
else if(variableEx3 >= 10 && variableEx3 < 12){
    printf("passable \n");
}
else if (variableEx3 < 14){
    printf("assez bien \n");
}
else if (variableEx3 < 16){
    printf("bien \n");
}
else {
    printf("très bien \n");
}

/* exercice 4 */
if (variableEx4 == 'a' || variableEx4 == 'o' ||variableEx4 == 'i' || variableEx4 == 'e' || 
variableEx4 == 'y' || variableEx4 == 'u'){
    printf("voyelle \n");
}
else {
    printf("consonne \n");
}

/* exercice 5 */
if (variableEx5 == 1){
  printf("lundi\n");
}
else if (variableEx5 == 2){
  printf("mardi\n");
}
else if (variableEx5 == 3){
  printf("mercredi\n");
}
else if (variableEx5 == 4){
  printf("jeudi\n");
}
else if (variableEx5 == 5){
  printf("vendredi\n");
}
else if (variableEx5 == 6){
  printf("samedi\n");
}
else if (variableEx5 == 7){
  printf("dimanche\n");
}
else{
  printf("Entrée invalide! Veuillez saisir le numéro de jour entre 1 et 7.");
}

/* exercice 6 */
/*
if(variableEx6 == 1){
  printf("31 jours");
  }
else if(variableEx6 == 2){
  printf("28/29 jours");
}
else if(variableEx6 == 3){
  printf("31 jours");
}
else if(variableEx6 == 4){
  printf("30 jours");
}
else if(variableEx6 == 5){
  printf("31 jours");
}
else if(variableEx6 == 6){
  printf("30 jours");
}
else if(variableEx6 == 7){
  printf("31 jours");
}
else if(variableEx6 == 8){
  printf("31 jours");
}
else if(variableEx6 == 9){
  printf("30 jours");
}
else if(variableEx6 == 10){
  printf("31 jours");
}
else if(variableEx6 == 11){
  printf("30 jours");
}
else if(variableEx6 == 12){
  printf("31 jours");
}
else{
  printf("Entrée invalide! Veuillez saisir le numéro du mois entre (1-12).");
}
*/

/* exercice 7 */
if (variableEx7_fab > variableEx7_ven){
    printf("perte \n");
}
else {
    printf("profit \n");
}

/* exercice 8 */
if ((variableEx8 % 4 == 0 && variableEx8 % 100 != 0) || variableEx8 % 400 == 0){
    printf("année bissextile\n");
}
else {
    printf("non bissextile\n");
}

/* exercice 9 */
if ((variableEx9 >= 65 && variableEx9 <= 90) || (variableEx9 >= 97 && variableEx9 <= 122)){  
  printf("alphabet \n");  
}
else if (variableEx9 >= 9){
  printf("chiffre \n");
}
else{
  printf("symbole \n");
}

  return 0;
}