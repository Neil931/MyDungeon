#include <stdio.h>
#include <stdlib.h>
#include "array.h"
#include "rectangle.h"

int main(void) {  
  int *a = (int*)build_array(sizeof(int), 5);
  int b = 5; 
  int* c = &b;
  
  //init_array(a, 3, c);
  //print_array(a, 3, "%d");   
  //free_array(a);
  //char* d = (char*)buil_array(sizeof(char), 5);
  
  return 0;
}