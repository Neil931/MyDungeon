/*
#ifndef RECTANGLE_H
#define RECTANGLE_H

struct Point {
  int x; 
  int y;   
}

typedef struct{
  int longueur;
  int largueur; 
}Rectangle; 

#endif
*/