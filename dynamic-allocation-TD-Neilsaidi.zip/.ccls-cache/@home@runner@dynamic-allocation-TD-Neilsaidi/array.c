#include "array.h"
#include <stdlib.h>

void* build_array(int size, int length){ 
  return malloc (size * length);
}

void free_array(void* array){
  //free_array(a);
}