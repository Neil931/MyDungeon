#include <stdio.h>
#include "rectangle.h"
/*
struct point p{
  p.x = 10;
  p.y = 20;
}
struct point P2 = {5, 2}; 
struct point P3 = {.y = 5, .x = 10}; 

struct Rectangle r = {10, 5}
  printf("%d %d\n", r.longueur, r.largueur);

rectangle *r = malloc(sizeof (rectangle));
r -> Longueur = 10
r -> Longueur = 15
printf("%d\n", Perimetre(r));
*/