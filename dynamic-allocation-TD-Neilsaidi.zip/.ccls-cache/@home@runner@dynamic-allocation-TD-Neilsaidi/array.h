#ifndef ARRAY_H
#define ARRAY_H

void* build_array(int size, int length);
void free_array(void* array);

#endif