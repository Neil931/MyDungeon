#include <stdio.h>

int my_strlen(char *s);
void my_strupcase(char *str);
void my_strlowcase(char *str);
int my_strcmp(char *str1, char *str2);
int my_strncmp(char *str1, char *str2, int n);
int my_strcasecmp(char *str1, char *str2);
int my_strncasecmp(char *str1, char *str2, int n);
int my_strspn(char *s, char *accept);
int my_strcspn(char *s, char *reject);
int my_strstr(char *fullstring, char *substring);
int my_atoi(char *str);

int main(void) {

  int a[4] = {1, 3, 5, 7};
  char s[255] = "AbCDEfgHI";
  printf("%d \n", my_strlen(s));

  my_strupcase(s);
  printf("%s \n", s);   

  my_strlowcase(s);
  printf("%s \n", s);

  char s1[255] = "ABC";    
  char s2[255] = "ABC";
  printf("my_strcmp : %d \n", my_strcmp(s1, s2));
       
  printf("my_strncmp : %d \n", my_strncmp(s1, s2,4));
  
  printf("my_strcasecmp %d \n", my_strcasecmp(s1, s2)); 
  
  printf("my_strncasecmp %d \n", my_strncasecmp(s1,s2,4));
    
  char * c = "neinl001";
  char * acceptedChars = "abcdefghijklmnopqrstuvwxyz";
  char * rejectedChars = "n";
  printf("my_strspn : %d \n", my_strspn(c, acceptedChars));
  printf("my_strcspn :%d \n", my_strcspn(c, rejectedChars));
  
  char *fullstring ="Bonj Neil n"; 
  char *substring="Neil"; 
  printf("my_strstr : %d \n", my_strstr(fullstring,  
  substring));

  char *number ="985786"; 
  printf("my_atoi : %d \n", my_atoi(number));

  return 0;
}

//EXERCICE 01 :
int my_strlen(char *s){
  int compteur = 0;
  for (int i = 0; s[i] != '\0'; i++){      
    compteur++;
  }
  return compteur;
}

//EXERCICE 02 :
void my_strupcase(char *str){
    for(int i = 0; str[i] != '\0'; i++){
       
        if ((int) str[i] >= 97 && (int) str[i] <= 122){
            str[i] = str[i] -32;
        }        
    }
}

//EXERCICE 03 :
void my_strlowcase(char *str){
    for(int i = 0; str[i] != '\0'; i++){
       
        if ((int) str[i] >= 65 && (int) str[i] <= 90){
            str[i] = str[i] +32;
        }        
    }
}

//EXERCICE 04 :
int my_strcmp(char *str1, char *str2){    

  for(int i = 0; str1[i] == str2[i] && str1[i] != '\0'; i++){

    if(str1[i] > str2[i]){
      return 1;
    }
    else if (str1[i] < str2[i]){
      return -1;
    }         
  }   
  return 0;
}

//EXERCICE 05 :
int my_strncmp(char *str1, char *str2, int n){
  for(int i = 0; (str1[i] != '\0' || str2[i] != '\0') && i<n; 
  i++){ 

    if(str1[i] > str2[i]){
    return 1;
    }
    else if (str1[i] < str2[i]){
      return -1;
    }     
  }   
  return 0;
} 

//EXERCICE 06
int my_strcasecmp(char *str1, char *str2){

  char c1; 
  char c2;

  for(int i = 0; str1[i] != '\0' || str2[i] != '\0'; i++){

    c1 = str1[i]; 
    c2 = str2[i];

    if ((int) str1[i] >= 97 && (int) str1[i] <= 122){
            c1 = str1[i] -32;
    }             
    if ((int) str2[i] >= 97 && (int) str2[i] <= 122){
            c2 = str2[i] - 32;
    }
    if (c1 > c2){
      return 1;
    }
    else if (c1 < c2){
      return -1;
    }     
  }   
  return 0;
}

// EXERCICE 07 
int my_strncasecmp(char *str1, char *str2, int n){  

  char c1; 
  char c2;

  for(int i = 0; (str1[i] != '\0' || str2[i] != '\0') && i<n; 
  i++){

    c1 = str1[i]; 
    c2 = str2[i];

    if ((int) str1[i] >= 97 && (int) str1[i] <= 122){
            c1 = str1[i] -32;
    }         
    if ((int) str2[i] >= 97 && (int) str2[i] <= 122){
            c2 = str2[i] - 32;
    }

    if (c1 > c2){
    return 1;
    }
    else if (c1 < c2){
    return -1;
    }     
  }   
  return 0;
}

//EXERCICE 08 
int my_strspn (char *s, char *accept){

  int length = 0;
  int cpt=0;

  for(int i = 0; s[i] != '\0'; i++){        
    cpt=0;     
    for(int j = 0; accept[j] != '\0'; j++){

      if (s[i] == accept[j]){
        length++;
        cpt++;
      }
    }    
    if (cpt==0) return length;
  }
  return length; 
}

//EXERCICE 09
int my_strcspn (char *s, char *reject){
int length = 0;

  for(int i = 0; s[i] != '\0'; i++){    
    for(int j = 0; reject[j] != '\0'; j++){

      if (s[i] == reject[j]){        
        return length;        
      }
    }
    length++; 
  }
  return length; 
}

//EXERCICE 10 
int my_strstr (char *fullstring, char *substring){
int index=-1;
int i=0; 
    
  for(int j = 0; fullstring[j] != '\0'; j++){
    
    if ( substring[i] != fullstring[j] ){
      index=-1; 
      i=0; 
    } 
    if (i==0 &&  substring[i] == fullstring[j]){
      index=j;         
    }      
      i++; 
    if (substring[i]=='\0') return index;
    }    
  return index; 
}

//EXERCICE 11
int my_atoi (char *str){
  int result=0; 
  int nbr;
  int n ; 

  for(int i=0; str[i]!='\0'; i++) {

    if(str[i] >='0' && str[i] <= '9'){      
      nbr=1; 
      n= my_strlen(str)-i-1; 

      for (int j=0; j<n; j++) {
        nbr= 10 *nbr;
      }
      nbr= (str[i]-'0') * nbr;     
      result= result + nbr;        
    }
    else {
      return -1; 
    }   
  }
  return result; 
}

