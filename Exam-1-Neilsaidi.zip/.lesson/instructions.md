# Exam : DES VARIABLES ET DES CONDITIONS
## Consigne : 


***TOUT VOS PRINTF DOIVENT FINIR PAR \n ***

le code des Exercice doivent être écrit à la place des //TODO

vous pouvez passer un exercice en écrivant 
```c
printf("skip");
```
## rappel de syntax
```c
int a = 10;         //Entier
char c = 'a';       //Charactere
char* d = "toto";   //Chaine de Charactere

printf("%d \n", a);
printf("%c \n", c);
printf("%s \n", d);

if (/*Expression Boolean*/){
    //Calcules
}
else if (/*Expression Boolean*/){
    //Calcules
}
else {
    //Calcules
}


```


## lancer les testes :

### Tester son code : 
vous pouvez modifier les valeurs des variable mais **pas** leur identifiant.

les valeurs sont par défaut 0, vous pouvez modifier ces valeurs. 

## Exercice 0 : 
Écrivez un programme pour vérifier si un nombre est pair ou impair en utilisant if-else.
afficher : "pair" ou "impair" 
## Exercice 1 : 
Écrivez un programme pour trouver un maximum entre trois nombres en utilisant une if-else ou if imbriquée.

Afficher le nombre maximume
## Exercice 2 : 
Écrivez un programme pour vérifier si un nombre est divisible par 3 et 13 ou non, en utilisant if-else.

afficher : "divisible" ou "non divisible"
## Exercice 3 :
Écrivez un programme pour déterminer la mention obtenu par un élève en fonction de sa note 
- S’il a une moyenne strictement inferieure a 10, le programme affiche "recalé".
- S’il a une moyenne entre 10 (inclus) et 12, il obtient la mention "passable".
- S’il a une moyenne entre 12 (inclus) et 14, il obtient la mention "assez bien".
- S’il a une moyenne entre 14 (inclus) et 16, il obtient la mention "bien".
- S’il a une moyenne superieure à 16 (inclus) il obtient la mention "très bien".
## Exercice 4 :
Écrivez un programme pour vérifier si un alphabet est une voyelle ou une consonne en utilisant if-else.
Les lettres a, e, i, o et u en minuscules et en majuscules sont appelées voyelles. Les alphabets autres que les voyelles sont appelés consonnes.

le programme affichera "voyelle" ou "consonne"
## Exercice 5 :
Écrivez un programme pour entrer le numéro du jour de la semaine (1-7) et affichez le nom du jour de la semaine correspondant en utilisant if-else.

le programme affichera : "lundi" ou "mardi" ou "mercredi" ... 

## Exercice 6 :
Écrivez un programme pour entrer le numéro du mois entre (1-12) et afficher le nombre de jours de ce mois en utilisant if-else.

Le nombre total de jours dans un mois est donné par le tableau ci-dessous.

| Mois | Nombre de jours (et message à afficher) |
|:-----|:----------------|
|Janvier, Mars, Mai, Juillet, Aout, Octobre, Décembre | "31 jours"
| Février |	"28/29 jours"
| Avril, Juin, Septembre, Novembre | "30 jours"

## Exercice 7 :
Écrivez un programme pour saisir le prix de fabrication et le prix de vente d'un produit et vérifiez le profit ou la perte.
Si le prix de fabrication est supérieur au prix de vente, il y a perte sinon profit.

afficher : "perte" ou "profit"


## Exercice 8 :
Écrivez un programme pour vérifier si l'année donnée par l'utilisateur est bissextile ou non, en utilisant if-else.

Année bissextile c'est une année spéciale contenant un jour supplémentaire, soit un total de 366 jours dans une année. Une année est considérée comme une année bissextile si l'année est exactement divisible par 4 mais non divisible par 100. L'année est également une année bissextile si elle est exactement divisible par 400.

afficher "bissextile" ou "non bissextile"

## Exercice 9 :
Écrivez un programme pour vérifiez si le caractère donné est un alphabet, un chiffre ou un caractère spécial en utilisant if-else.

    - Un caractère est un alphabet s'il se situe entre a-z ou A-Z.
    - Un caractère est un chiffre s'il est compris entre 0 et 9.
    - Un caractère est un symbole spécial s'il est ni alphabet ni chiffre.

afficher : "alphabet" ou "chiffre" ou "symbole"


