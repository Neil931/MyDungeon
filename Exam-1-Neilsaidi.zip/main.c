#include <stdio.h>

int main(void) {
    
/* Variables */
/* exercice 0 */
    int variableEx0 = 0;  
    
/* exercice 1 */
    int variableEx1_1 = 0;
    int variableEx1_2 = 0;
    int variableEx1_3 = 0;
  
/* exercice 2 */
    int variableEx2 = 0;
   
/* exercice 3 */
    int variableEx3 = 0;

/* exercice 4 */
    char variableEx4 = 'a';

/* exercice 5 */
    int variableEx5 = 1;
 
/* exercice 6 */
    char variableEx6[64] = "Mai";
    

/* exercice 7 */
    int variableEx7_fab = 0;
    int variableEx7_ven = 0; 

/* exercice 8 */
    int variableEx8 = 0; 

/* exercice 9 */
    char variableEx9 = 'a'; 


/**
                DEBUT DU DEVOIR
**/

/* exercice 0 */
 if (variableEx0 % 2 != 0){
      printf("%d impair \n", variableEx0);      
    }
    else{
      printf("%d paire \n",  variableEx0);      
    }

/* exercice 1 */

if ((variableEx1_1 > variableEx1_2) && (variableEx1_1 > variableEx1_3)){
  printf(" %d est le nombre est le Maximume \n", variableEx1_1);
}
else if ((variableEx1_2 > variableEx1_1) && (variableEx1_2 > variableEx1_3)){
  printf(" %d est le nombre est le Maximume \n", variableEx1_2);
}
else if ((variableEx1_3 > variableEx1_1) && (variableEx1_3 > variableEx1_2)){
  printf(" %d est le nombre est le Maximume \n", variableEx1_3);
}

/* exercice 2 */
if ((variableEx2 % 2) == 0 ){
  printf("Le nombre est est divisiblenon divisible \n");
}
else{ printf("Le nombre non divisible \n");
}

/* exercice 3 */
if(variableEx3 < 10){
  printf("recalé \n");
}
else if(variableEx3 >= 10 && variableEx3 < 12 && variableEx3 <= 20){
  printf("passable \n");
}
else if(variableEx3 >= 12 && variableEx3 < 14 && variableEx3 <= 20){
  printf("assez bien \n");
}
else if(variableEx3 >= 14 && variableEx3 < 16 && variableEx3 <= 20){
  printf("bien \n");
}
else if(variableEx3 >= 16 && variableEx3 <= 20){
  printf("très bien \n");
}

/* exercice 4 */
if(variableEx4 == 'a' || variableEx4 == 'e' || variableEx4 == 'i' || variableEx4 == 'o' || variableEx4 == 'u' ||variableEx4 == 'y'){
  printf("voyelle \n");
}
else{
  printf("consonne \n");
}
/* exercice 5 */
if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 1 ){
  printf("lundi \n");
}
else if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 2){
  printf("mardi \n");
}
else if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 3){
  printf("mercredi \n");
}
else if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 4){
  printf("jeudi \n");
}
else if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 5){
  printf("vendredi \n");
}
else if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 6){
  printf("samedi \n");
}
else if(variableEx5 >= 1 && variableEx5 <= 7 && variableEx5 == 7){
  printf("dimanche \n");
}
else{
  printf(" pas valide \n");
}

/* exercice 6 */ 


/* exercice 7 */
if(variableEx7_fab > variableEx7_ven){
  printf("perte \n");  
}
else if (variableEx7_ven < variableEx7_fab){
  printf("Profit \n");

}
 
/* exercice 8 */
if(variableEx8 % 4 == 0 &&  variableEx8 % 100 !=0){
  printf("%d est Bisextile \n",variableEx8); 
}
  else {
    printf("%d n'est pas bisextile \n,", variableEx8);
  }

}

/* exercice 9 */
// TODO
  return 0;
}


