#include <stdio.h>

void array_display(int array[], int size);
void array_init_zero(int array[], int size);
void array_init(int array[], int size, int initializer);
void array_even(int array[], int size);
void array_series_i(int array[], int size);
void array_facto(int array[], int size);
void array_max(int array[], int size, int maxValue);
int array_sum(int array[], int size);
double array_average(int array[], int size);
void array_cpy(int array_src[], int array_dst[], int tailleTableau);
void array_sort(int array[], int size);

int main(void) {
  
    int e1[5] = {1, 3, 12, 24, 0};
    int e2[5] = {1, 3, 12, 24, 0};
    int e3[5] = {1, 3, 12, 24, 0};
    int e4[5] = {1, 3, 12, 24, 0};
    int e5[5] = {1, 3, 12, 24, 0};

    array_sort(e1, 5);
    array_display(e1, 5);

    array_init_zero(e1, 5);
    array_display(e1, 5);

    array_init(e1, 5, 42);
    array_display(e1, 5);
    
    array_even(e2, 5);

    array_series_i(e3, 5);
    array_display(e3, 5);

    array_facto(e3, 5);
    array_display(e3, 5);
    
    array_max(e4, 5, 10);
    array_display(e4, 5);

    int a = array_sum(e5, 5);
    printf("%d \n", a);

    int b = array_average(e5, 5);
    printf("%d \n", b);
    
  return 0;
}

// EXERCICE 0
void array_display(int array[], int size){
    for(int i = 0; i < size; i++){
        printf("%d \n", array[i]);
    }
}

// EXERCICE 1
void array_init_zero(int array[], int size){
    for(int i = 0; i < size; ++i){
        array[i] = 0;
    }
}

// EXERCICE 2
void array_init(int array[], int size, int initializer){
    for(int i = 0; i < size; ++i){
        array[i] = initializer;
    }
}

//EXERCICE 3
void array_even(int array[], int size){
    for(int i = 0; i < size; i++){
        if (array[i] % 2 == 0){
            printf("%d \n", array[i]);
        }
    }
}

//EXERCICE 4
void array_series_i(int array[], int size){
    for(int i = 0; i < size; i++){
        array[i] = 2 * i + 1;
    }
}

//EXERCICE 5
void array_facto(int array[], int size){
    array[0] = 1;
    for (int i = 1; i < size; i++){
        array[i] = array[i - 1] * i;
    }
}

//EXERCICE 6
void array_max(int array[], int size, int maxValue){
    for (int i = 0; i < size; i++){
        if (array[i] > maxValue){
            array[i] = 0;
        }
    }
}

//EXERCICE 7
int array_sum(int array[], int size){
    int count = 0;
    for (int i = 0; i < size; i++){
        count = count + array[i];
    }
    return count;
}

//EXERCICE 8
double array_average(int array[], int size){
    int count = array_sum(array, size);
    return (double) count / size;
}

//EXERCICE 9
void array_cpy(int array_src[], int array_dst[], int size){
    for(int i = 0; i < size; i++){
        array_dst[i] = array_src[i];
    }
}

//EXERCICE 10
void array_sort(int array[], int size){
    for(int i = 0; i < size; i++){
        for(int j = 1; j < size; j++){
            if(array[j - 1] > array[j]){
                int tmp = array[j];
                array[j] = array[j - 1];
                array[j - 1] = tmp;
            }
        }
    }
}