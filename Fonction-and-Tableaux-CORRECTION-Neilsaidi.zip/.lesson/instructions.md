# Sommaire
1. la boucle for
2. Les tableaux
3. Exercices

# la boucle for
En théorie, la boucle `while` permet de réaliser toutes les boucles que l'on veut.
Toutefois, il est dans certains cas utile d'avoir un autre système de boucle plus « condensé », plus rapide à écrire.

Les boucles `for` sont très très utilisées en programmation.

 les boucles `for` sont juste une autre façon de faire une boucle `while`.

Voici un exemple de boucle`while` :

```c
int compteur = 0;

while (compteur < 10)
{
    printf("Salut les Zeros !\n");
    compteur++;
}
```
Voici maintenant l'équivalent en boucle `for`:

```c

for (int compteur = 0 ; compteur < 10 ; compteur++)
{
    printf("Salut les Zeros !\n");
}
```
Quelles différences
- Vous noterez que l'on n'a pas initialisé la variable`compteur`à 0 dès sa déclaration (mais on aurait pu le faire).
- Il y a beaucoup de choses entre les parenthèses après le`for`(nous allons détailler ça après).
- Il n'y a plus de `compteur++;` dans la boucle.

Intéressons-nous à ce qui se trouve entre les parenthèses, car c'est là que réside tout l'intérêt de la boucle `for`. Il y a trois instructions condensées, chacune séparée par un point-virgule.

- La première est **l'initialisation** : cette première instruction est utilisée pour préparer notre variable `compteur`. Dans notre cas, on initialise la variable à 0.

- La seconde est la **condition** : comme pour la boucle `while`, c'est la condition qui dit si la boucle doit être répétée ou non. Tant que la condition est vraie, la boucle `for` continue.

- Enfin, il y a **l'incrémentation** : cette dernière instruction est exécutée à la fin de chaque tour de boucle pour mettre à jour la variable `compteur`. La quasi-totalité du temps on fera une incrémentation, mais on peut aussi faire une décrémentation (variable--) ou encore n'importe quelle autre opération (`variable += 2;` pour avancer de 2 en 2 par exemple).

Bref, comme vous le voyez la boucle `for` n'est rien d'autre qu'un condensé. Sachez vous en servir, vous en aurez besoin plus d'une fois !

# Tableaux 
## Définir un tableau

Pour commencer, nous allons voir comment définir un tableau de 4 ```int```:
```c
int tableau[4];
```
Voilà, c'est tout. Il suffit donc de rajouter entre crochets le nombre de cases que vous voulez mettre dans votre tableau. Il n'y a pas de limite (à part peut-être la taille de votre mémoire, quand même).

Maintenant, comment accéder à chaque case du tableau ? C'est simple, il faut
```c
identifiantTableau[numeroDeLaCase].
```

Attention : un tableau commence à l'indice n° 0 ! Notre tableau de 4 `int` a donc les indices 0, 1, 2 et 3. Il n'y a pas d'indice 4 dans un tableau de 4 cases ! C'est une source d'erreurs très courantes, souvenez-vous-en.

Si je veux mettre dans mon tableau les mêmes valeurs que celles indiquées sur la fig. suivante, je devrai donc écrire :
```c
int tableau[4];


tableau[0] = 10;

tableau[1] = 23;

tableau[2] = 505;

tableau[3] = 8;
```

Comme toutes les variables vous pouvez afficher les valeurs d'un tableau à l'aide de printf

```c
int tableau[4];

printf("%d", *tableau);
```

## les tableau à taille dynamique

Le langage C existe en plusieurs versions.
Une version récente, appelée le C99, autorise la création de tableaux à taille dynamique, c'est-à-dire de tableaux dont la taille est définie par une variable :

```c
int taille = 5;
int tableau[taille];
```

Or cela n'est pas forcément reconnu par tous les compilateurs, certains planteront sur la seconde ligne. Le langage C que je vous enseigne depuis le début (appelé le C89) n'autorise pas ce genre de choses. Nous considèrerons donc que faire cela est interdit.

Nous allons nous mettre d'accord sur ceci : vous n'avez pas le droit d'utiliser une variable entre crochets pour la définition de la taille du tableau, même si cette variable est une constante ! Le tableau doit avoir une dimension fixe, c'est-à-dire que vous devez écrire noir sur blanc le nombre correspondant à la taille du tableau :

```c
int tableau[5];
```
## Parcourir un tableau
Supposons que je veuille maintenant afficher les valeurs de chaque case du tableau.
Je pourrais faire autant de `printf` qu'il y a de cases. Mais bon, ce serait répétitif et lourd, et imaginez un peu la taille de notre code si on devait afficher le contenu de chaque case du tableau une à une !

Le mieux est de se servir d'une boucle. Pourquoi pas d'une boucle `for` ? Les boucles `for` sont très pratiques pour parcourir un tableau :
```c
int main(int argc, char *argv[])
{
    int tableau[4], i = 0;

    tableau[0] = 10;
    tableau[1] = 23;
    tableau[2] = 505;
    tableau[3] = 8;

    for (i = 0 ; i < 4 ; i++)
    {
        printf("%d\n", tableau[i]);
    }

    return 0;
}
```
ce qui donne : 
```
10

23

505

8
```
Notre boucle parcourt le tableau à l'aide d'une variable appelée `i` (c'est le nom très original que les programmeurs donnent en général à la variable qui leur permet de parcourir un tableau !).

Ce qui est particulièrement pratique, c'est qu'on peut mettre une variable entre crochets. En effet, la variable était interdite pour la création du tableau (pour définir sa taille), mais elle est heureusement autorisée pour « parcourir » le tableau, c'est-à-dire afficher ses valeurs !
Ici, on a mis la variable `i`, qui vaut successivement 0, 1, 2, et 3. De cette façon, on va donc afficher la valeur de 
```c
tableau[0],tableau[1],tableau[2] et tableau[3]
```
*Attention à ne pas tenter d'afficher la valeur de `tableau[4]`! Un tableau de 4 cases possède les indices 0, 1, 2 et 3, point barre. Si vous tentez d'afficher `tableau[4]`, vous aurez soit n'importe quoi, soit une belle erreur, l'OS coupant votre programme car il aura tenté d'accéder à une adresse ne lui appartenant pas.*

## initialiser un tableau

Maintenant que l'on sait parcourir un tableau, nous sommes capables d'initialiser toutes ses valeurs à 0 en faisant une boucle !

Bon, parcourir le tableau pour mettre 0 à chaque case:
```c
int main(int argc, char *argv[])
{
    int tableau[4], i = 0;

    // Initialisation du tableau
    for (i = 0 ; i < 4 ; i++)
    {
        tableau[i] = 0;
    }

    // Affichage de ses valeurs pour vérifier
    for (i = 0 ; i < 4 ; i++)
    {
        printf("%d\n", tableau[i]);
    }

    return 0;
}
```
### Une autre façon d'initialiser
Il faut savoir qu'il existe une autre façon d'initialiser un tableau un peu plus automatisée en C.
Elle consiste à écrire`tableau[4] = {valeur1, valeur2, valeur3, valeur4}`. En clair, vous placez les valeurs une à une entre accolades, séparées par des virgules :
```c
int main(int argc, char *argv[])
{
    int tableau[4] = {0, 0, 0, 0}, i = 0;

    for (i = 0 ; i < 4 ; i++)
    {
        printf("%d\n", tableau[i]);
    }

    return 0;
}
```
Mais en fait, c'est même mieux que ça : vous pouvez définir les valeurs des premières cases du tableau, toutes celles que vous n'aurez pas renseignées seront automatiquement mises à 0.

Ainsi, si je fais :

```c
int tableau[4] = {10, 23}; // Valeurs insérées : 10, 23, 0, 0
```
… la case n° 0 prendra la valeur 10, la n° 1 prendra 23, et toutes les autres prendront la valeur 0 (par défaut).

Comment initialiser tout le tableau à 0 en sachant ça ?
Eh bien il vous suffit d'initialiser au moins la première valeur à 0, et toutes les autres valeurs non indiquées prendront la valeur 0.


```c
int tableau[4] = {0}; // Toutes les cases du tableau seront initialisées à 0
```
Cette technique a l'avantage de fonctionner avec un tableau de n'importe quelle taille (là, ça marche pour 4 cases, mais s'il en avait eu 100 ça aurait été bon aussi).

*Attention, on rencontre souventint `tableau[4] = {1};`, ce qui insère les valeurs suivantes : 1, 0, 0, 0.
Contrairement à ce que beaucoup d'entre vous semblent croire, on n'initialise pas toutes les cases à 1 en faisant cela : seule la première case sera à 1, les autres seront à 0. On ne peut donc pas initialiser toutes les cases à 1 automatiquement, à moins de faire une boucle.*

## Passage de tableaux à une fonction
Vous aurez à coup sûr souvent besoin d'afficher tout le contenu de votre tableau. Pourquoi ne pas écrire une fonction qui fait ça ? Ça va nous permettre de découvrir comment on envoie un tableau à une fonction (ce qui m'arrange).

Il va falloir envoyer deux informations à la fonction : le tableau (enfin, l'adresse du tableau) et aussi et surtout sa taille !
En effet, notre fonction doit être capable d'initialiser un tableau de n'importe quelle taille. Or, dans votre fonction, vous ne connaissez pas la taille de votre tableau. C'est pour cela qu'il faut envoyer en plus une variable que vous appellerez par exemple`tailleTableau`.


```c
// Prototype de la fonction d'affichage
void affiche(int tableau[], int tailleTableau);
 
int main(int argc, char *argv[])
{
    int tableau[4] = {10, 15, 3};
 
    // On affiche le contenu du tableau
    affiche(tableau, 4);
 
    return 0;
}
 
void affiche(int tableau[], int tailleTableau)
{
    int i;
 
    for (i = 0 ; i < tailleTableau ; i++)
    {
        printf("%d\n", tableau[i]);
    }
}
```


```c
```


```c
```
# Exercices


## Exercice 1
Créez une fonction `array_init_zero` qui à pour role d'initialiser toutes les case d'un tableau à 0

```c
void array_init_zero(int array[], int size);
```

## Exercice 2
Créez une fonction `array_init` qui à pour role d'initialiser toutes les case d'un tableau avec une variable passé en paramètres

```c
void array_init(int array[], int size, int initializer);
```

## Exercice 3
Créez une fonction `array_even` qui va afficher tous les éléments pair d'un tableau passé en paramètres

```c
void array_even(int array[], int size);
```

## Exercice 4
Créez une fonction `array_series_i` qui va initialiser un tableau avec les éléments de la suite 2i + 1 commenceant à 0
exemple un tableau de 4 case devra ressembler à ça après execution : 
{1, 3, 5, 7}

```c
void array_series_i(int array[], int size);
```

## Exercice 5
Créez une fonction `array_facto` qui va initialiser un tableau avec chaque factorielle de son index

Rappel factorielle :0! = 1, 1! = 1, 2! = 1 * 2, 3! = 1 * 2 * 3, 4! = 1 * 2 * 3 * 4;

un tableau de 6 case devra donc ressembler à ça au final : 
{1, 1, 2, 6, 25, 720}

```c
void array_facto(int array[], int size);
```
## Exercice 6
Créez une fonction `array_max` qui aura pour rôle de remettre à 0 toutes les cases du tableau ayant une valeur supérieure à un maximum. Cette fonction prendra en paramètres le tableau ainsi que le nombre maximum autorisé (maxValue). Toutes les cases qui contiennent un nombre supérieur à `maxValue` doivent être mises à 0.

```c
void array_max(int array[], int size, int maxValue);
```
## Exercice 7

Créez une fonction `array_sum` qui renvoie la somme des valeurs contenues dans le tableau (utilisez un `return` pour renvoyer la valeur). Pour vous aider, voici le prototype de la fonction à créer :


```c
int array_sum(int array[], int size);
```

## Exercice 8
Écrire une fonction `array_average` qui renvois la moyenne des éléments du tableau
rappel : la moyenne est la somme de tous les éléménts du tableau divisé par le nombre d'élément
```c
double array_average(int array[], int size);
```

## Exercice 9
Créez une procédure `array_cpy` qui prend en paramètre deux tableaux. Le contenu du premier tableau devra être copié dans le second tableau.

les tableaux doivent être de même taille

```c
void array_cpy(int array_src[], int array_dst[], int tailleTableau);
```


## Exercices 10
Créez une fonctionor `array_sort` qui classe les valeurs d'un tableau dans l'ordre croissant. Ainsi, un tableau qui vaut{15, 81, 22, 13}doit à la fin de la fonction valoir{13, 15, 22, 81}

```c
void array_sort(int array[], int size);
```

```c
```

```c
```

```c
```

```c
```

```c
```

```c
```

```c
```

```c
```

```c
```
