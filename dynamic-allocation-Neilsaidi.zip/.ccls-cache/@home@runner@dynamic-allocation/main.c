#include <stdio.h>
#include <stdlib.h>

int main(void) {
  printf("Hello World\n");
    //allouer de la mémoire dynamique
    int *a = malloc(sizeof(int));
    char *b = malloc(sizeof(char));
    

    //vérification 
    if (a == NULL || b == NULL){
        printf("erreur pointeur\n");
        exit(1);
    }
    *a = 10;
    *b = 'c';
    printf("%d\n", *a);
    free(a);
    // ça si vous le faites, je vous défonce. 
    printf("%c\n", *a);
    *a = 10;
    printf("%d\n", *a);
    //fin de si vous le faites je vous défonce.

    char *uni_array = malloc(sizeof(char) * 6);
    uni_array[0] = 's';
    uni_array[1] = 's';
    uni_array[2] = 'a';
    uni_array[3] = 's';
    uni_array[4] = 's';
    uni_array[5] = '\0';
    free(uni_array);
    printf("%s \n", uni_array);
    
    int size = 3;
    int **bi_int_array = malloc(sizeof(int *) * size);
    for(int i = 0; i < size; i++){
        bi_int_array[i] = malloc(sizeof(int) * size);
    }

    //free
    for(int i = 0; i < size; i++){
        free(bi_int_array[i]);
    }
    free(bi_int_array);
    
  
  return 0;
}