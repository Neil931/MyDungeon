#include <stdio.h>

int main(void) {
    
 return 0;
}

//EXERCICE 1 : Villes et villages 
int VilleVillage(){ 
    return 0; 
}

//Validation : Planning de la journée
int PJournee( ){
  //TODO
    return 0;
}

//EXERCICE 2 : Étape la plus longue
  //TODO
//Exercice 3 : Calcul des dénivelées
  //TODO  
//Exercice 4 : Type d'arbres
  //TODO  
//Exercice 5 : Tarifs de l'auberge
  //TODO  
//Exercice 6
  //TODO 
//Validation : Le juste prix
  //TODO 