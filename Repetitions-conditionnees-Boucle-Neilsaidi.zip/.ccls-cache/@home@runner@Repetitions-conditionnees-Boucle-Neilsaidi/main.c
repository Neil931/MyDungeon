#include <stdio.h>
#include <stdbool.h>

int main(void) {

// EXERCICE 1 : 
/*  
  int malades = 1;
  int jours = 1;
  int hab = 10000;

  while (malades < hab){
    malades = malades + malades * 2;
    jours = jours + 1;
  }
  printf("%d jours\n", jours);
*/  

//EXERCICE 2
/*  
  int ent;
  int add = 0;

  while (ent != -1){
    printf("entrez les entiers: ");
    scanf("%d", &ent);
  if (ent > 0){
    add = add + ent;
  }
  }
  printf ("%d", add);
*/   

// EXERCICE 3 :  
/*
  int essais = 0;
  int nbr_secret = 20;
  int nbr;

  while (nbr != nbr_secret){
      scanf ("%d", &nbr);
      essais = essais + 1;
    if (nbr < nbr_secret){
      printf ("c'est plus!\n");
    }
    else if (nbr > nbr_secret){
      printf ("c'est moins!\n");
    }
    else{
      printf ("trouvé!\n");
    }
  }
  
  if (essais == 1){
    printf ("nombre d'essais nécessiares:\n");
    printf ("%d essai\n", essais);
  }
  else{
    printf ("nombre d'essais nécessiares:\n");
    printf ("%d essais\n", essais);
  }
*/  

//Validation :
/*  
  int temp_max = 20;
  int temp_min = 9;
  int temp_var = 10;

  while (temp_var > temp_min && temp_var < temp_max){
    if (temp_var > temp_min && temp_var < temp_max){
      printf ("Rien à signaler");
    }
    else{
      printf ("Alerte !!");
    }
  }  
*/
  return 0;
} 

