# Répétition conditionnées : Boucle

## Exercice 1: Département de médecine : contrôle d'une épidémie

Afin de pouvoir mieux combattre les différentes épidémies, parfois très graves, qui se développent régulièrement dans la région, le département de médecine de l'université a lancé une grande étude. En particulier, les chercheurs s'intéressent à la vitesse de propagation d'une épidémie et donc à la vitesse à laquelle des mesures sanitaires doivent êtres mises en place.

#### Ce que doit faire votre programme :

Votre programme doit d'abord lire un entier, la population totale de la ville. Sachant qu'une personne était malade au jour 1 et que chaque malade contamine deux nouvelles personnes le jour suivant (et chacun des jours qui suivent), vous devez calculer à partir de quel jour toute la population de la ville sera malade.

#### Exemple :
```
input:

3

output:

2

Exemple2

input:

10

output:

4
```

#### Commentaire


On a 1 malade le premier jour, donc 2 nouveaux malades le second jour, soit un total de 3 malades. On a donc 6 nouveaux malades au troisième jour, soit un total de 9 malades. On a donc 18 nouveaux malades au quatrième jour, soit…

## **Faire la même chose plusieurs fois : le « tant que »**
On a parfois besoin de répéter certaines instructions jusqu'à ce qu'un certain changement ce soit produit. Par exemple, demander un mot de passe tant que l'utilisateur n'a pas donné le bon.

On a ici utilisé dans la phrase le terme « tant que », ce qui signifie qu'on a bien une condition pour savoir quand s'arrêter. On ne peut pas utiliser notre boucle « répéter » habituelle, car on ne sait pas combien de fois l'utilisateur va se tromper !

On va donc faire intervenir une autre boucle : la boucle « tant que », que nous allons manipuler dans ce chapitre. Elle se nomme while dans les langages de programmation (traduction en anglais de « tant que »).

```c
int secret = 123456;
int motDePasse = 0;
while (motDePasse != secret)
{
   printf("Entrez le mot de passe :\n");
   scanf("%d", &motDePasse);
}
printf("Vous avez trouvé !\n");
```

Il est bien sûr possible d'utiliser des opérateurs booléens pour combiner des conditions et les valeurs booléennes sont également utilisables. Voici quelques extraits de code à titre d'exemple :
```c
while (true)
{
   printf("J'attends");
}

while (motDePasse != secret || agePersonne <= 3)
{
   printf("Accès refusé : mauvais mot de passe ou personne trop jeune\n");
   scanf("%d%d", &agePersonne, &motDePasse);
}

while (nbPersonnes <= nbMax && temperature <= 45)
{
   printf("Portes ouvertes\n");
   nbPersonnes = nbPersonnes + 1;
   scanf("%d", &temperature);
}
```

Le premier de ces trois exemples est ce qu'on appelle une « boucle infinie », c'est-à-dire que le programme ne s'arrête jamais : comme true est toujours vrai, on ne quitte jamais la boucle.

## Boucle infinie

Dans un code utilisant une boucle « tant que », si on utilise une mauvaise condition, il est possible que le programme ne s'arrête jamais. Par exemple :
```
valeur <- 1
Tant que valeur <= 10 faire
   valeur <- valeur - 1
   ```

Ici, on a mis valeur - 1 au lieu de valeur + 1 ; du coup, la variable valeur ne fait que diminuer au lieu d'augmenter. Elle ne sera donc jamais plus grande que 10 et le programme ne s'arrêtera jamais (en supposant les limites des entiers infinies) !

Si vous écrivez un tel programme, le système d'évaluation automatique du site vous indiquera que « votre programme a dépassé la limite de temps ». En effet, pour éviter les programmes qui ne s'arrêtent jamais, nous avons un système qui les bloque automatiquement s'ils mettent trop de temps à donner leur réponse.

Si vous voyez un tel message, essayez de vérifier les conditions dans vos boucles.

### Exercice 2 : Administration : comptes annuels

Une grande partie du travail de l'administration de l'université, en plus de gérer les enseignants, les étudiants, les cours… est de veiller au bon fonctionnement de l'université et en particulier à ce que les comptes soient bien tenus. En particulier il faut, une fois par an, faire un bilan annuel des dépenses.

Toutes les dépenses de l'année ont été enregistrées et classées dans une multitude de dossiers et il faut maintenant calculer la somme de toutes ces dépenses. Mais personne ne sait exactement combien de dépenses différentes ont été effectuées durant l'année écoulée !

#### Ce que doit faire votre programme :

Votre programme devra lire une suite d'entiers positifs et afficher leur somme. On ne sait pas combien il y aura d'entiers, mais la suite se termine toujours par la valeur -1 (qui n'est pas une dépense, juste un marqueur de fin).

#### Exemple
```
input:

1000
2000
500
-1

output:

3500

Exemple2

input:

-1

output:

0
```

### Exercice 3 : Département de pédagogie : le « c'est plus, c'est moins »

Dans une cité commerçante, il est important que les habitants soient forts en calcul mental afin de pouvoir négocier leurs prix et choisir les meilleurs produits sans se faire avoir. Le département de pédagogie de l'université a donc été sollicité afin de mettre au point des exercices stimulants pour les enfants, qui vont les inciter à travailler leur calcul mental.

Réalisant le potentiel que peut avoir votre robot dans un cadre pédagogique, les chercheurs vous demandent de mettre au point un programme capable de faire jouer de manière automatisée un enfant au jeu du « c'est plus, c'est moins » : l'enfant doit deviner un nombre secret en faisant des propositions, et on lui répond chaque fois par « c'est plus » ou « c'est moins », jusqu'à ce qu'il ait trouvé le bon nombre.

L'objectif est bien sûr pour les enfants de trouver le bon nombre le plus rapidement possible !

#### Ce que doit faire votre programme :

Votre programme doit d'abord lire un entier, le nombre que l'enfant devra trouver. Ensuite, il devra lire les propositions du joueur, et afficher à chaque fois le texte « c'est plus » (l'enfant a proposé un nombre trop petit) ou « c'est moins » (l'enfant a proposé un nombre trop grand) selon les cas, et recommencer tant que l'enfant n'a pas trouvé le bon nombre.

À la fin, il faudra afficher le texte « Nombre d'essais nécessaires : » puis, à la ligne en dessous, le nombre d'essais qui ont été nécessaires.

On vous garantit que l'enfant finira par trouver la bonne valeur !
#### Exemple : 
```
input:

5
1
2
3
4
5

output:

c'est plus
c'est plus
c'est plus
c'est plus
Nombre d'essais nécessaires :
5

Exemple2 : 

input:

10
5
15
8
12
11
10

output:

c'est plus
c'est moins
c'est plus
c'est moins
c'est moins
Nombre d'essais nécessaires :
6

Exemple3 :

input:


-50
-80
-50

output:

c'est plus

Nombre d'essais nécessaires :
2
```

## Validation : Département d'architecture : construction d'une pyramide

Les habitants adorent les constructions en forme de pyramide ; de nombreux bâtiments officiels ont d'ailleurs cette forme. Pour fêter les 150 ans de la construction de la ville, le gouverneur a demandé la construction d'une grande et majestueuse pyramide à l'entrée de la ville. Malheureusement, en ces périodes de rigueur budgétaire, il y a peu d'argent pour ce projet. Les architectes souhaitent cependant construire la plus grande pyramide possible étant donné le budget prévu.

#### Ce que doit faire votre programme :

Votre programme doit d'abord lire un entier : le nombre maximum de pierres dont pourra être composée la pyramide. Il devra ensuite calculer et afficher un entier : la hauteur de la plus grande pyramide qui pourra être construite, ainsi que le nombre de pierres qui sera nécessaire.

#### Exemple :
```
input:

20

output:

3
14

Exemple2 :

input:

26042

output:

42
25585
```

### Validation : Département de chimie : mélange explosif

Les chimistes de l'université ont mis au point un nouveau procédé de fabrication d'un onguent qui permet une cicatrisation très rapide des blessures. Ce procédé est cependant très long et nécessite une surveillance de tous les instants de la préparation en train de chauffer, et ce parfois pendant des heures. Confier cette tâche à un étudiant n'est pas possible, ils s'endorment toujours ou ne font pas attention… et cela risque alors d'exploser !

Un dispositif automatique de surveillance de la préparation serait donc intéressant. Celui-ci surveillerait la température toutes les 15 secondes, et si celle-ci devient anormale alors une alarme devrait sonner, afin de prévenir tout le monde.

#### Ce que doit faire votre programme :

Votre programme devra lire trois entiers : le nombre total de mesures envisagées ainsi que la température minimum et maximum autorisées. Les entiers suivants seront les différentes températures relevées au cours du temps.

Tant que les températures relevées restent dans le bon intervalle, votre programme devra écrire le texte « Rien à signaler », mais dès que la température n'est pas bonne il doit écrire le texte « Alerte !! » et s'arrêter.

#### Exemple :
```
input:

5
10
20
15
10
20
0
15

output:

Rien à signaler
Rien à signaler
Rien à signaler
Alerte !!

Exemple2 :

input:

3
0
100
15
50
75

output:

Rien à signaler
Rien à signaler
Rien à signaler
```




















  