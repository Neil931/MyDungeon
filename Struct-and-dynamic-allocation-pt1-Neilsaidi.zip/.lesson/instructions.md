### Exercice 1.1
Décrire la structure Point dans un fichier point.h
La structure point comporte deux attributs :

```c
typedef struct {
    int x;
    int y;
} Point;
```
### Exercice 1.2
Ecrire la fonction `build_point` qui Retourne un pointeur sur un nouvelle emplacement mémoire Point
```c
Point *build_point(int x, int y);
```

### Exercice 1.3
Ecrire la fonction `norme_point` qui affiche uniquement la distance entre l'origine du repère et le point en cours
```c
int norme(Point *p);
```

### Exercice 2.1
Ecrire la structure Book qui possède les attributs suivant : 
```c
char title[255];
char autor[255];
int price;
```
### Exercice 2.2
Ecrire la fonction `build_book` qui retourne un pointeur sur un nouvelle emplacement mémoire Book
```c
Book *build_book(char title[], char autor[], int price);
```

### Exercice 2.3
Ecrire la fonction `display_book` qui affiche tous les éléments du livre passé en paramètre
```c
void display_book(Book *p);
```
### Exercice 3.1
Ecrire la structure Rectangle qui possède les attributs suivant : 
```c
int length;
int width;
```

### Exercice 3.2
Ecrire la fonction `build_rectangle` qui retourne un pointeur sur un nouvelle emplacement mémoire Rectangle
```c
Rectangle *build_rectangle(int length; int width);
```


### Exercice 3.3
Ecrire la fonction `perimetre_rectangle` retourne le périmètre du rectangle
```c
int perimetre_rectangle(Rectangle *p);
```
### Exercice 3.4
Ecrire la fonction `aire_rectangle` retourne l'aire du rectangle
```c
int aire_rectangle(Rectangle *p);
```

### Exercice 3.5
Ecrire la fonction `is_square_rectangle` retourne 1 si le rectangle est un carré, 0 sinon;
```c
int is_square_rectangle(Rectangle *p);
```

### Exercice 4.1
Ecrire la structure Circle qui possède les attributs suivant : 
```c
Point *center;
int radius;
```

### Exercice 4.2
Ecrire la fonction `build_circle` qui retourne un pointeur sur un nouvelle emplacement mémoire Circle
```c
Circle *build_Circle(Point *center; int radius);
```

### Exercice 4.3
Ecrire la fonction `perimetre_circle` retourne le périmètre du cercle
```c
int perimetre_circle(Circle *c);
```

### Exercice 4.4
Ecrire la fonction `surface_circle` qui retourne la valeur de l'aire du cercle
```c
int surface_circle(Circle *c);
```

### Exercice 4.5
Ecrire la fonction `is_in_circle` qui retourne 1 si le point p est contenu dans le cercle, 0 sinon
```c
int is_in_circle(point *p);
```
