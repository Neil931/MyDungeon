#include "book.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// EXERCICE 2.2 :
Book *build_book(char title[], char autor[], int price){
  Book *p = malloc(sizeof(Book));      
  strcpy(p->title, title);
  strcpy(p->autor, autor);   
  p->price = price;    
  return p;   
}
  
// EXERCICE 2.3 :
void display_book(Book *p){
  printf("title : %s, autor : %s, price : %d \n", p->title,
  p->autor, p->price);
}

