#include <stdio.h>
#include <stdlib.h> 
#include "point.h"
#include "book.h"
#include "rectangle.h"
#include "circle.h"

int main(void) {    
  // structure Point 
  Point *new_point = build_point(10, 5);
  
  printf("build_point : x = %d, y = %d\n", new_point->x,           new_point->y);
  printf("norme_point : %lf\n", norme(new_point));     
  
  free(new_point);  
  
  // structure Book 
  Book *new_book = build_book("title", "autor", 3);
  display_book(new_book);
  free(new_book); 
  
  // structure Rectangle 
  Rectangle *new_rectangle = build_rectangle(5, 5);    

  printf("length = %d, width = %d\n", new_rectangle->width,        new_rectangle->length);
  
  printf("Périmetre rec = %d\n",                     
  perimetre_rectangle(new_rectangle));  
  
  printf("Aire rec :%d\n", aire_rectangle(new_rectangle));
  printf(" %d\n", is_square_rectangle(new_rectangle));
  
  free(new_rectangle); 
  
  // structure Circle  
  Point *center = build_point(0, 0);
  Circle *new_circle = build_circle(center, 5); 
  Point *p = build_point(6, 6);  
  
  printf("Périmètre cer: %d \n", perimetre_circle(new_circle));
  printf("Air cer : %d \n", surface_circle(new_circle));
  printf(" %d \n", is_in_circle(p, new_circle)); 
  
  free(p); 
  free(new_circle); 
  free(center); 
  
  return 0;
}