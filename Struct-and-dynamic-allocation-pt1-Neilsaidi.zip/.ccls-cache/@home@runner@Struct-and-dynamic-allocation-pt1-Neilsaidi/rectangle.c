#include "rectangle.h"
#include <stdlib.h>

// EXERCICE 3.2 : 
Rectangle *build_rectangle(int length, int width){    
  Rectangle *p = malloc(sizeof(Rectangle));  

  p->width = width;
  p->length = length; 
  return p;  
}

// EXERCICE 3.3 : 
int perimetre_rectangle(Rectangle *p){  
  return(p->width + p->length)*2;
}

// EXERCICE 3.4 :
int aire_rectangle(Rectangle *p){
  return(p->width * p->length);
}

// EXERCICE 3.5 : 
int is_square_rectangle(Rectangle *p){
  
  if(p->width == p->length){
  return 1;
  }
  else{
  return 0; 
  }
}
