#ifndef BOOK_H
#define BOOK_H

typedef struct {
    char title[255];
    char autor[255];
    int price;   
} Book;

extern Book *build_book(char title[], char autor[], int price);
extern void display_book(Book *p);

#endif