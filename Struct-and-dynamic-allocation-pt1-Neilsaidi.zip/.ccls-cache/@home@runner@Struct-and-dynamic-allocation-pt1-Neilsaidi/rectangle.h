#ifndef RECTANGLE_H
#define RECTANGLE_H

typedef struct {
    int length;
    int width;
} Rectangle;

Rectangle *build_rectangle(int length, int width);
int perimetre_rectangle(Rectangle *p);
int aire_rectangle(Rectangle *p);
int is_square_rectangle(Rectangle *p); 

#endif
