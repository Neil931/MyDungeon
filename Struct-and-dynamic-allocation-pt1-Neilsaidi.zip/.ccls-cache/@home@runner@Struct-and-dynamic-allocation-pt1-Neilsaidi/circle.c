#include "circle.h"
#include <stdlib.h>

// EXERCICE 4.2 :
Circle *build_circle(Point *center, int radius){ 
  Circle *c = malloc(sizeof(Circle));  

  c->center = center;
  c->radius = radius; 
  return c;   
}

// EXERCICE 4.3 :
int perimetre_circle(Circle *c){
  return c->radius * 2 * 3.14; 
}

// EXERCICE 4.4 :
int surface_circle(Circle *c){
  return 3.14 * c->radius * c->radius;   
}

// EXERCICE 4.5 :
int is_in_circle(Point *p, Circle *c){
  double distance;
  distance = (p->x - c->center->x)*(p->x - c->center->x) + 
  (p->y - c->center->y)*(p->y - c->center->y);
  
  if(distance <= c->radius){
  return 1;
  }
  else{
  return 0; 
  }  
}