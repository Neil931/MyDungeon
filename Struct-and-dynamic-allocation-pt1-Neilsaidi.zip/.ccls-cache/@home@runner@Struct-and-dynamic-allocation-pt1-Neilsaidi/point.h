#ifndef POINT_H
#define POINT_H

typedef struct {
    int x;
    int y;
} Point;

extern Point *build_point(int x, int y);
extern double norme(Point *p);

#endif