#include "point.h"
#include <math.h>
#include <stdlib.h>

// EXERCICE 1.2 : 
//memoireAllouee = malloc(sizeof(int)); 
Point *build_point(int x, int y){    
  Point *p = malloc(sizeof(Point));  
  
  Point c; 
  c.x = 10; 
  c.y = 14;
  //OU
  p->x = x;
  p->y = y;  
  return p;   
}

// EXERCICE 1.3 : 
double norme(Point *p){   
  int x = p->x;
  int y = p->y;
  int resultat = x*x + y*y;
  double resultat2 = sqrt(resultat);    
  // N°1
  return resultat2;  
  // N°2
  return sqrt(pow(p->x, 2) + pow(p->y, 2));   
  // N°3
  return sqrt(p->x * p->x + p->y * p->y);
}
// EXERCICE 2.1 : 





