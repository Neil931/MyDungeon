#ifndef CIRCLE_H
#define CIRCLE_H
#include "point.h"

typedef struct {
    Point *center;
    int radius;     
} Circle;

extern Circle *build_circle(Point *center, int radius);
extern int perimetre_circle(Circle *c);
int surface_circle(Circle *c);
int is_in_circle(Point *p, Circle *c);

#endif