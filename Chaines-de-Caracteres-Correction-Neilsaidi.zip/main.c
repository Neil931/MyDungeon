#include <stdio.h>
#include <string.h>

int my_strlen(char *s);
void my_strupcase(char *str);
void my_strlowcase(char *str);
int my_strcmp(char *str1, char *str2);
int my_strncmp(char *str1, char *str2, int n);
int my_strcasecmp(char *str1, char *str2);
int my_strcasecmp2(char *str1, char *str2);
int my_strncasecmp(char *str1, char *str2, int n);
int my_strspn ( char *s,   char *accept);
int my_strcspn ( char *s,   char *reject);
int my_strstr (char *fullstring,   char *substring);
int my_atoi (char *str);
int powten(int n);

int main(void) {
      printf("Hello World\n");

    int a[4] = {1, 3, 5, 7};
    char s[255] = "totoAsalut  test Test";
    char *s2 = "toto";
    char *s3 = "toTo";
    printf("%d \n", my_strlen(s));

    my_strupcase(s);
    my_strlowcase(s);

    printf("%s \n", s);
    
    printf("%d\n", my_strcmp(s2, s3));
    printf("%d\n", my_strncmp(s2, s3, 2));
    printf("%d\n", powten(4));
  return 0;
}

//"toto" -> 4
//[t, o, t, o, \0, .... ]
//EXERCICE 1 :
int my_strlen(char *s){
    int compteur = 0;
    for (int i = 0; s[i] != '\0'; i++){
        compteur++;
    }
    return compteur;
}

//EXERCICE 2 :
void my_strupcase(char *str){
    for(int i = 0; str[i] != '\0'; i++){
        
        if ((int) str[i] >= 97 && (int) str[i] <= 122){
            str[i] = str[i] - 32;
        }  
    }
}

//EXERCICE 3 :
void my_strlowcase(char *str){
    for(int i = 0; str[i] != '\0'; i++){
        
        if ((int) str[i] >= 65 && (int) str[i] <= 90){
            str[i] = str[i] + 32;
        }   
    }
}

//EXERCICE 4 :
int my_strcmp(char *str1, char *str2){
    int i = 0;
  
    while (str1[i] == str2[i] && str1[i] != '\0'){
        i++;
    }
    if (str1[i] == '\0'){
        return 0;
    }
    else if (str1[i] > str2[i]){
        return 1;
    }
    else {
        return -1;
    }
}

//EXERCICE 5 :
int my_strncmp(char *str1, char *str2, int n){
    int i = 0;
    while (str1[i] == str2[i] && str1[i] != '\0' && i < n){
        i++;
    }
    if (str1[i] == '\0' || i == n) {
        return 0;
    }
    else if (str1[i] > str2[i]){
        return 1;
    }
    else {
        return -1;
    }    
}

//EXERCICE 6 #1
int my_strcasecmp(char *str1, char *str2){
    int i = 0;
    while ((str1[i] == str2[i] 
        || ((str1[i] >= 65 && str1[i] <= 90) && (str2[i] >= 97  && str2[i] <= 122))
        || ((str2[i] >= 65 && str2[i] <= 90) && (str1[i] >= 97  && str1[i] <= 122))
        ) 
        && str1[i] != '\0'){
        i++;
    }   
  
    if (str1[i] == '\0'){
        return 0;
    }
    else if (str1[i] > str2[i]){
        return 1;
    }
    else {
        return -1;
    }
}

int my_strcasecmp2(char *str1, char *str2){
    int i;
    
    for (i = 0; str1[i] != '\0' && str2[i] != '\0'; i++){
        char a;
        char b;
        
        if ((int) str1[i] >= 97 && (int) str1[i] <= 122){
            a = str1[i] - 32;
        }
        if ((int) str2[i] >= 97 && (int) str2[i] <= 122){
            b = str2[i] - 32;
        }
        if (a != b)
            break;   
    }   

    if (str1[i] == '\0'){
        return 0;
    }
    else if (str1[i] > str2[i]){
        return 1;
    }
    else {
        return -1;
    }
}

//EXERCICE 7
int my_strncasecmp(char *str1, char *str2, int n){
  int i;
  
  for (i = 0; str1[i] != '\0' && str2[i] != '\0' && i < n; i++){
    char a;
    char b;
    
    if ((int) str1[i] >= 97 && (int) str1[i] <= 122){
      a = str1[i] - 32;
    }
    if ((int) str2[i] >= 97 && (int) str2[i] <= 122){
      b = str2[i] - 32;
    }
    if (a != b)
      break;   
    }    

    if (str1[i] == '\0' || i == n){   
    }
    else if (str1[i] > str2[i]){
      return 1;
    }
    else{
      return -1;
  }
}

//EXERCICE 8
int my_strspn ( char *s,   char *accept){
    int compteur = 0;
    for (int i = 0; s[i] != '\0'; i++){
        for (int j = 0; accept[j] != '\0'; j++){
            if (s[i] == accept[j]){
                compteur++;
                break;
            }
        }
    }   
}

//EXERCICE 9 :
int my_strcspn ( char *s,   char *reject){
     int compteur = 0;
    for (int i = 0; s[i] != '\0'; i++){
        for (int j = 0; reject[j] != '\0'; j++){
            if (s[i] != reject[j]){
                compteur++;
                break;
            }
        }
    }   
}

//EXERCICE 10 :
int my_strstr (char *s,   char *s2){
  int j = 0;
  int i = 0;
  int compteur = -1;
  
  while (s[i] != '\0'){
    if (s[i] == s2[j]){
      compteur = i;
      while(s[i] != '\0' && s2[j] != '\0' && s[i] == s2[j]){
          i++;
          j++;
      }
      if(s2[j] == '\0')
      return compteur;
      j = 0;
      compteur = -1;
    }
    i++;
  }  
  return compteur;
}

int powten(int n){
    int c = 1;
    for(int i = 0; i < n - 1; i++){
        c *= 10;
    }
    return c;
}

//EXERCICE 11 :
int my_atoi (char *str){
  
    int size = my_strlen(str);
    int pow = powten(size);
    int compteur = 0;
  
    for(int i = 0; str[i] != '\0'; i++){
        
        if(str[i] < 48 || str[i] > 57){
            printf("erreur chiffre invalid \n");
            return -1;
        }
        
        compteur = compteur + ((int) str[i] - 48) * pow;
        pow = pow / 10;
    }
    return compteur;    
}