# Les tableaux 
## Définir un tableau

Pour commencer, nous allons voir comment définir un tableau de 4 ```int```:
```c
int tableau[4];
```
Voilà, c'est tout. Il suffit donc de rajouter entre crochets le nombre de cases que vous voulez mettre dans votre tableau. Il n'y a pas de limite (à part peut-être la taille de votre mémoire, quand même).

Maintenant, comment accéder à chaque case du tableau ? C'est simple, il faut
```c
identifiantTableau[numeroDeLaCase].
```

Attention : un tableau commence à l'indice n° 0 ! Notre tableau de 4 `int` a donc les indices 0, 1, 2 et 3. Il n'y a pas d'indice 4 dans un tableau de 4 cases ! C'est une source d'erreurs très courantes, souvenez-vous-en.

Si je veux mettre dans mon tableau les mêmes valeurs que celles indiquées sur la fig. suivante, je devrai donc écrire :
```c
int tableau[4];


tableau[0] = 10;

tableau[1] = 23;

tableau[2] = 505;

tableau[3] = 8;
```

Comme toutes les variables vous pouvez afficher les valeurs d'un tableau à l'aide de printf

```c
int tableau[4];

printf("%d", *tableau);
```

## les tableau à taille dynamique

Le langage C existe en plusieurs versions.
Une version récente, appelée le C99, autorise la création de tableaux à taille dynamique, c'est-à-dire de tableaux dont la taille est définie par une variable :

```c
int taille = 5;
int tableau[taille];
```

Or cela n'est pas forcément reconnu par tous les compilateurs, certains planteront sur la seconde ligne. Le langage C que je vous enseigne depuis le début (appelé le C89) n'autorise pas ce genre de choses. Nous considèrerons donc que faire cela est interdit.

Nous allons nous mettre d'accord sur ceci : vous n'avez pas le droit d'utiliser une variable entre crochets pour la définition de la taille du tableau, même si cette variable est une constante ! Le tableau doit avoir une dimension fixe, c'est-à-dire que vous devez écrire noir sur blanc le nombre correspondant à la taille du tableau :

```c
int tableau[5];
```
## Parcourir un tableau
Supposons que je veuille maintenant afficher les valeurs de chaque case du tableau.
Je pourrais faire autant de `printf` qu'il y a de cases. Mais bon, ce serait répétitif et lourd, et imaginez un peu la taille de notre code si on devait afficher le contenu de chaque case du tableau une à une !

Le mieux est de se servir d'une boucle. Pourquoi pas d'une boucle `for` ? Les boucles `for` sont très pratiques pour parcourir un tableau :
```c
int main(int argc, char *argv[])
{
    int tableau[4], i = 0;

    tableau[0] = 10;
    tableau[1] = 23;
    tableau[2] = 505;
    tableau[3] = 8;

    for (i = 0 ; i < 4 ; i++)
    {
        printf("%d\n", tableau[i]);
    }

    return 0;
}
```
ce qui donne : 
```
10

23

505

8
```
Notre boucle parcourt le tableau à l'aide d'une variable appelée `i` (c'est le nom très original que les programmeurs donnent en général à la variable qui leur permet de parcourir un tableau !).

Ce qui est particulièrement pratique, c'est qu'on peut mettre une variable entre crochets. En effet, la variable était interdite pour la création du tableau (pour définir sa taille), mais elle est heureusement autorisée pour « parcourir » le tableau, c'est-à-dire afficher ses valeurs !
Ici, on a mis la variable `i`, qui vaut successivement 0, 1, 2, et 3. De cette façon, on va donc afficher la valeur de 
```c
tableau[0],tableau[1],tableau[2] et tableau[3]
```
*Attention à ne pas tenter d'afficher la valeur de `tableau[4]`! Un tableau de 4 cases possède les indices 0, 1, 2 et 3, point barre. Si vous tentez d'afficher `tableau[4]`, vous aurez soit n'importe quoi, soit une belle erreur, l'OS coupant votre programme car il aura tenté d'accéder à une adresse ne lui appartenant pas.*

## initialiser un tableau

Maintenant que l'on sait parcourir un tableau, nous sommes capables d'initialiser toutes ses valeurs à 0 en faisant une boucle !

Bon, parcourir le tableau pour mettre 0 à chaque case:
```c
int main(int argc, char *argv[])
{
    int tableau[4], i = 0;

    // Initialisation du tableau
    for (i = 0 ; i < 4 ; i++)
    {
        tableau[i] = 0;
    }

    // Affichage de ses valeurs pour vérifier
    for (i = 0 ; i < 4 ; i++)
    {
        printf("%d\n", tableau[i]);
    }

    return 0;
}
```
### Une autre façon d'initialiser
Il faut savoir qu'il existe une autre façon d'initialiser un tableau un peu plus automatisée en C.
Elle consiste à écrire`tableau[4] = {valeur1, valeur2, valeur3, valeur4}`. En clair, vous placez les valeurs une à une entre accolades, séparées par des virgules :
```c
int main(int argc, char *argv[])
{
    int tableau[4] = {0, 0, 0, 0}, i = 0;

    for (i = 0 ; i < 4 ; i++)
    {
        printf("%d\n", tableau[i]);
    }

    return 0;
}
```
Mais en fait, c'est même mieux que ça : vous pouvez définir les valeurs des premières cases du tableau, toutes celles que vous n'aurez pas renseignées seront automatiquement mises à 0.

Ainsi, si je fais :

```c
int tableau[4] = {10, 23}; // Valeurs insérées : 10, 23, 0, 0
```
… la case n° 0 prendra la valeur 10, la n° 1 prendra 23, et toutes les autres prendront la valeur 0 (par défaut).

Comment initialiser tout le tableau à 0 en sachant ça ?
Eh bien il vous suffit d'initialiser au moins la première valeur à 0, et toutes les autres valeurs non indiquées prendront la valeur 0.


```c
int tableau[4] = {0}; // Toutes les cases du tableau seront initialisées à 0
```
Cette technique a l'avantage de fonctionner avec un tableau de n'importe quelle taille (là, ça marche pour 4 cases, mais s'il en avait eu 100 ça aurait été bon aussi).

*Attention, on rencontre souventint `tableau[4] = {1};`, ce qui insère les valeurs suivantes : 1, 0, 0, 0.
Contrairement à ce que beaucoup d'entre vous semblent croire, on n'initialise pas toutes les cases à 1 en faisant cela : seule la première case sera à 1, les autres seront à 0. On ne peut donc pas initialiser toutes les cases à 1 automatiquement, à moins de faire une boucle.*

## Passage de tableaux à une fonction
Vous aurez à coup sûr souvent besoin d'afficher tout le contenu de votre tableau. Pourquoi ne pas écrire une fonction qui fait ça ? Ça va nous permettre de découvrir comment on envoie un tableau à une fonction (ce qui m'arrange).

Il va falloir envoyer deux informations à la fonction : le tableau (enfin, l'adresse du tableau) et aussi et surtout sa taille !
En effet, notre fonction doit être capable d'initialiser un tableau de n'importe quelle taille. Or, dans votre fonction, vous ne connaissez pas la taille de votre tableau. C'est pour cela qu'il faut envoyer en plus une variable que vous appellerez par exemple`tailleTableau`.


```c
// Prototype de la fonction d'affichage
void affiche(int tableau[], int tailleTableau);
 
int main(int argc, char *argv[])
{
    int tableau[4] = {10, 15, 3};
 
    // On affiche le contenu du tableau
    affiche(tableau, 4);
 
    return 0;
}
 
void affiche(int tableau[], int tailleTableau)
{
    int i;
 
    for (i = 0 ; i < tailleTableau ; i++)
    {
        printf("%d\n", tableau[i]);
    }
}
```


```c
```


```c
```