# la boucle for
En théorie, la boucle `while` permet de réaliser toutes les boucles que l'on veut.
Toutefois, il est dans certains cas utile d'avoir un autre système de boucle plus « condensé », plus rapide à écrire.

Les boucles `for` sont très très utilisées en programmation.

 les boucles `for` sont juste une autre façon de faire une boucle `while`.

Voici un exemple de boucle`while` :

```c
int compteur = 0;

while (compteur < 10)
{
    printf("Salut les Zeros !\n");
    compteur++;
}
```
Voici maintenant l'équivalent en boucle `for`:

```c

for (int compteur = 0 ; compteur < 10 ; compteur++)
{
    printf("Salut les Zeros !\n");
}
```
Quelles différences
- Vous noterez que l'on n'a pas initialisé la variable`compteur`à 0 dès sa déclaration (mais on aurait pu le faire).
- Il y a beaucoup de choses entre les parenthèses après le`for`(nous allons détailler ça après).
- Il n'y a plus de `compteur++;` dans la boucle.

Intéressons-nous à ce qui se trouve entre les parenthèses, car c'est là que réside tout l'intérêt de la boucle `for`. Il y a trois instructions condensées, chacune séparée par un point-virgule.

- La première est **l'initialisation** : cette première instruction est utilisée pour préparer notre variable `compteur`. Dans notre cas, on initialise la variable à 0.

- La seconde est la **condition** : comme pour la boucle `while`, c'est la condition qui dit si la boucle doit être répétée ou non. Tant que la condition est vraie, la boucle `for` continue.

- Enfin, il y a **l'incrémentation** : cette dernière instruction est exécutée à la fin de chaque tour de boucle pour mettre à jour la variable `compteur`. La quasi-totalité du temps on fera une incrémentation, mais on peut aussi faire une décrémentation (variable--) ou encore n'importe quelle autre opération (`variable += 2;` pour avancer de 2 en 2 par exemple).

Bref, comme vous le voyez la boucle `for` n'est rien d'autre qu'un condensé. Sachez vous en servir, vous en aurez besoin plus d'une fois !
