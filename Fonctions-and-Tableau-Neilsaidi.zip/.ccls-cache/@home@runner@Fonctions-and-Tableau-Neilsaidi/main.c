#include <stdio.h>

void array_init_zero(int array[], int size);
void array_init(int array[], int size, int initializer);
void array_even(int array[], int size);
void array_series_i(int array[], int size);
void array_facto(int array[], int size);
void array_max(int array[], int size, int maxValue);
int array_sum(int array[], int size);
double array_average(int array[], int size);
void array_cpy(int array_src[], int array_dst[], int tailleTableau);
void array_sort(int array[], int size);

int main (void){
  
// EXERCICE 01 :
// EXERCICE 02 :
// EXERCICE 03 :  
// EXERCICE 04 :
// EXERCICE 06 :
// EXERCICE 07 :
// EXERCICE 08 :
// EXERCICE 09 :
// EXERCICE 10 :
  return 0; 
}

